

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=473 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_options VALUES("1","siteurl","http://localhost/cbdmed","yes");
INSERT INTO wp_options VALUES("2","home","http://localhost/cbdmed","yes");
INSERT INTO wp_options VALUES("3","blogname","CBDMed","yes");
INSERT INTO wp_options VALUES("4","blogdescription","","yes");
INSERT INTO wp_options VALUES("5","users_can_register","0","yes");
INSERT INTO wp_options VALUES("6","admin_email","hello@bulkdesign.com.br","yes");
INSERT INTO wp_options VALUES("7","start_of_week","0","yes");
INSERT INTO wp_options VALUES("8","use_balanceTags","0","yes");
INSERT INTO wp_options VALUES("9","use_smilies","1","yes");
INSERT INTO wp_options VALUES("10","require_name_email","","yes");
INSERT INTO wp_options VALUES("11","comments_notify","","yes");
INSERT INTO wp_options VALUES("12","posts_per_rss","10","yes");
INSERT INTO wp_options VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO wp_options VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO wp_options VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO wp_options VALUES("16","mailserver_pass","password","yes");
INSERT INTO wp_options VALUES("17","mailserver_port","110","yes");
INSERT INTO wp_options VALUES("18","default_category","1","yes");
INSERT INTO wp_options VALUES("19","default_comment_status","closed","yes");
INSERT INTO wp_options VALUES("20","default_ping_status","closed","yes");
INSERT INTO wp_options VALUES("21","default_pingback_flag","","yes");
INSERT INTO wp_options VALUES("22","posts_per_page","10","yes");
INSERT INTO wp_options VALUES("23","date_format","j \\d\\e F \\d\\e Y","yes");
INSERT INTO wp_options VALUES("24","time_format","H:i","yes");
INSERT INTO wp_options VALUES("25","links_updated_date_format","j \\d\\e F \\d\\e Y, H:i","yes");
INSERT INTO wp_options VALUES("26","comment_moderation","","yes");
INSERT INTO wp_options VALUES("27","moderation_notify","","yes");
INSERT INTO wp_options VALUES("28","permalink_structure","","yes");
INSERT INTO wp_options VALUES("29","rewrite_rules","","yes");
INSERT INTO wp_options VALUES("30","hack_file","0","yes");
INSERT INTO wp_options VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO wp_options VALUES("32","moderation_keys","","no");
INSERT INTO wp_options VALUES("33","active_plugins","a:8:{i:0;s:33:\"admin-menu-editor/menu-editor.php\";i:1;s:30:\"advanced-custom-fields/acf.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:53:\"contact-form-submissions/contact-form-submissions.php\";i:4;s:43:\"custom-post-type-ui/custom-post-type-ui.php\";i:5;s:26:\"post-smtp/postman-smtp.php\";i:6;s:27:\"woocommerce/woocommerce.php\";i:7;s:41:\"wp-database-backup/wp-database-backup.php\";}","yes");
INSERT INTO wp_options VALUES("34","category_base","","yes");
INSERT INTO wp_options VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO wp_options VALUES("36","comment_max_links","2","yes");
INSERT INTO wp_options VALUES("37","gmt_offset","","yes");
INSERT INTO wp_options VALUES("38","default_email_category","1","yes");
INSERT INTO wp_options VALUES("39","recently_edited","","no");
INSERT INTO wp_options VALUES("40","template","storefront","yes");
INSERT INTO wp_options VALUES("41","stylesheet","storefront","yes");
INSERT INTO wp_options VALUES("42","comment_whitelist","","yes");
INSERT INTO wp_options VALUES("43","blacklist_keys","","no");
INSERT INTO wp_options VALUES("44","comment_registration","","yes");
INSERT INTO wp_options VALUES("45","html_type","text/html","yes");
INSERT INTO wp_options VALUES("46","use_trackback","0","yes");
INSERT INTO wp_options VALUES("47","default_role","subscriber","yes");
INSERT INTO wp_options VALUES("48","db_version","38590","yes");
INSERT INTO wp_options VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO wp_options VALUES("50","upload_path","","yes");
INSERT INTO wp_options VALUES("51","blog_public","1","yes");
INSERT INTO wp_options VALUES("52","default_link_category","2","yes");
INSERT INTO wp_options VALUES("53","show_on_front","page","yes");
INSERT INTO wp_options VALUES("54","tag_base","","yes");
INSERT INTO wp_options VALUES("55","show_avatars","","yes");
INSERT INTO wp_options VALUES("56","avatar_rating","G","yes");
INSERT INTO wp_options VALUES("57","upload_url_path","","yes");
INSERT INTO wp_options VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO wp_options VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO wp_options VALUES("60","thumbnail_crop","1","yes");
INSERT INTO wp_options VALUES("61","medium_size_w","300","yes");
INSERT INTO wp_options VALUES("62","medium_size_h","300","yes");
INSERT INTO wp_options VALUES("63","avatar_default","mystery","yes");
INSERT INTO wp_options VALUES("64","large_size_w","1024","yes");
INSERT INTO wp_options VALUES("65","large_size_h","1024","yes");
INSERT INTO wp_options VALUES("66","image_default_link_type","none","yes");
INSERT INTO wp_options VALUES("67","image_default_size","","yes");
INSERT INTO wp_options VALUES("68","image_default_align","","yes");
INSERT INTO wp_options VALUES("69","close_comments_for_old_posts","","yes");
INSERT INTO wp_options VALUES("70","close_comments_days_old","14","yes");
INSERT INTO wp_options VALUES("71","thread_comments","","yes");
INSERT INTO wp_options VALUES("72","thread_comments_depth","5","yes");
INSERT INTO wp_options VALUES("73","page_comments","","yes");
INSERT INTO wp_options VALUES("74","comments_per_page","50","yes");
INSERT INTO wp_options VALUES("75","default_comments_page","newest","yes");
INSERT INTO wp_options VALUES("76","comment_order","asc","yes");
INSERT INTO wp_options VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO wp_options VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO wp_options VALUES("82","timezone_string","America/Sao_Paulo","yes");
INSERT INTO wp_options VALUES("83","page_for_posts","0","yes");
INSERT INTO wp_options VALUES("84","page_on_front","14","yes");
INSERT INTO wp_options VALUES("85","default_post_format","0","yes");
INSERT INTO wp_options VALUES("86","link_manager_enabled","0","yes");
INSERT INTO wp_options VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO wp_options VALUES("88","site_icon","0","yes");
INSERT INTO wp_options VALUES("89","medium_large_size_w","768","yes");
INSERT INTO wp_options VALUES("90","medium_large_size_h","0","yes");
INSERT INTO wp_options VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO wp_options VALUES("92","initial_db_version","38590","yes");
INSERT INTO wp_options VALUES("93","wp_user_roles","a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:115:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;s:19:\"manage_postman_smtp\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}","yes");
INSERT INTO wp_options VALUES("94","fresh_site","0","yes");
INSERT INTO wp_options VALUES("95","WPLANG","pt_BR","yes");
INSERT INTO wp_options VALUES("96","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("97","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("98","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("99","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("100","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("101","sidebars_widgets","a:1:{s:19:\"wp_inactive_widgets\";a:0:{}}","yes");
INSERT INTO wp_options VALUES("102","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("103","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("104","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("105","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("106","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("107","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("108","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("109","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("110","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("111","cron","a:12:{i:1531291476;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1531293528;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1531299431;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1531320276;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1531363487;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1531364231;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1531364241;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1531364400;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1531364565;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1531375031;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1533600000;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO wp_options VALUES("112","theme_mods_twentyseventeen","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1530586371;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}","yes");
INSERT INTO wp_options VALUES("116","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/pt_BR/wordpress-4.9.6.zip\";s:6:\"locale\";s:5:\"pt_BR\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/pt_BR/wordpress-4.9.6.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.6\";s:7:\"version\";s:5:\"4.9.6\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1530585881;s:15:\"version_checked\";s:5:\"4.9.6\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO wp_options VALUES("121","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1531282672;s:7:\"checked\";a:1:{s:10:\"storefront\";s:5:\"2.2.5\";}s:8:\"response\";a:1:{s:10:\"storefront\";a:4:{s:5:\"theme\";s:10:\"storefront\";s:11:\"new_version\";s:5:\"2.3.2\";s:3:\"url\";s:40:\"https://wordpress.org/themes/storefront/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/storefront.2.3.2.zip\";}}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:5:\"theme\";s:4:\"slug\";s:10:\"storefront\";s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"2.2.5\";s:7:\"updated\";s:19:\"2017-11-15 16:36:48\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/translation/theme/storefront/2.2.5/pt_BR.zip\";s:10:\"autoupdate\";b:1;}}}","no");
INSERT INTO wp_options VALUES("126","can_compress_scripts","1","no");
INSERT INTO wp_options VALUES("141","new_admin_email","hello@bulkdesign.com.br","yes");
INSERT INTO wp_options VALUES("148","current_theme","Storefront","yes");
INSERT INTO wp_options VALUES("149","theme_mods_storefront","a:7:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:16;}s:17:\"storefront_styles\";s:5060:\"\n			.main-navigation ul li a,\n			.site-title a,\n			ul.menu li a,\n			.site-branding h1 a,\n			.site-footer .storefront-handheld-footer-bar a:not(.button),\n			button.menu-toggle,\n			button.menu-toggle:hover {\n				color: #333333;\n			}\n\n			button.menu-toggle,\n			button.menu-toggle:hover {\n				border-color: #333333;\n			}\n\n			.main-navigation ul li a:hover,\n			.main-navigation ul li:hover > a,\n			.site-title a:hover,\n			a.cart-contents:hover,\n			.site-header-cart .widget_shopping_cart a:hover,\n			.site-header-cart:hover > li > a,\n			.site-header ul.menu li.current-menu-item > a {\n				color: #838383;\n			}\n\n			table th {\n				background-color: #f8f8f8;\n			}\n\n			table tbody td {\n				background-color: #fdfdfd;\n			}\n\n			table tbody tr:nth-child(2n) td,\n			fieldset,\n			fieldset legend {\n				background-color: #fbfbfb;\n			}\n\n			.site-header,\n			.secondary-navigation ul ul,\n			.main-navigation ul.menu > li.menu-item-has-children:after,\n			.secondary-navigation ul.menu ul,\n			.storefront-handheld-footer-bar,\n			.storefront-handheld-footer-bar ul li > a,\n			.storefront-handheld-footer-bar ul li.search .site-search,\n			button.menu-toggle,\n			button.menu-toggle:hover {\n				background-color: #ffffff;\n			}\n\n			p.site-description,\n			.site-header,\n			.storefront-handheld-footer-bar {\n				color: #6d6d6d;\n			}\n\n			.storefront-handheld-footer-bar ul li.cart .count,\n			button.menu-toggle:after,\n			button.menu-toggle:before,\n			button.menu-toggle span:before {\n				background-color: #333333;\n			}\n\n			.storefront-handheld-footer-bar ul li.cart .count {\n				color: #ffffff;\n			}\n\n			.storefront-handheld-footer-bar ul li.cart .count {\n				border-color: #ffffff;\n			}\n\n			h1, h2, h3, h4, h5, h6 {\n				color: #333333;\n			}\n\n			.widget h1 {\n				border-bottom-color: #333333;\n			}\n\n			body,\n			.secondary-navigation a,\n			.onsale,\n			.pagination .page-numbers li .page-numbers:not(.current), .woocommerce-pagination .page-numbers li .page-numbers:not(.current) {\n				color: #6d6d6d;\n			}\n\n			.widget-area .widget a,\n			.hentry .entry-header .posted-on a,\n			.hentry .entry-header .byline a {\n				color: #9f9f9f;\n			}\n\n			a  {\n				color: #96588a;\n			}\n\n			a:focus,\n			.button:focus,\n			.button.alt:focus,\n			.button.added_to_cart:focus,\n			.button.wc-forward:focus,\n			button:focus,\n			input[type=\"button\"]:focus,\n			input[type=\"reset\"]:focus,\n			input[type=\"submit\"]:focus {\n				outline-color: #96588a;\n			}\n\n			button, input[type=\"button\"], input[type=\"reset\"], input[type=\"submit\"], .button, .added_to_cart, .widget a.button, .site-header-cart .widget_shopping_cart a.button {\n				background-color: #eeeeee;\n				border-color: #eeeeee;\n				color: #333333;\n			}\n\n			button:hover, input[type=\"button\"]:hover, input[type=\"reset\"]:hover, input[type=\"submit\"]:hover, .button:hover, .added_to_cart:hover, .widget a.button:hover, .site-header-cart .widget_shopping_cart a.button:hover {\n				background-color: #d5d5d5;\n				border-color: #d5d5d5;\n				color: #333333;\n			}\n\n			button.alt, input[type=\"button\"].alt, input[type=\"reset\"].alt, input[type=\"submit\"].alt, .button.alt, .added_to_cart.alt, .widget-area .widget a.button.alt, .added_to_cart, .widget a.button.checkout {\n				background-color: #333333;\n				border-color: #333333;\n				color: #ffffff;\n			}\n\n			button.alt:hover, input[type=\"button\"].alt:hover, input[type=\"reset\"].alt:hover, input[type=\"submit\"].alt:hover, .button.alt:hover, .added_to_cart.alt:hover, .widget-area .widget a.button.alt:hover, .added_to_cart:hover, .widget a.button.checkout:hover {\n				background-color: #1a1a1a;\n				border-color: #1a1a1a;\n				color: #ffffff;\n			}\n\n			.pagination .page-numbers li .page-numbers.current, .woocommerce-pagination .page-numbers li .page-numbers.current {\n				background-color: #e6e6e6;\n				color: #6d6d6d;\n			}\n\n			#comments .comment-list .comment-content .comment-text {\n				background-color: #f8f8f8;\n			}\n\n			.site-footer {\n				background-color: #f0f0f0;\n				color: #6d6d6d;\n			}\n\n			.site-footer a:not(.button) {\n				color: #333333;\n			}\n\n			.site-footer h1, .site-footer h2, .site-footer h3, .site-footer h4, .site-footer h5, .site-footer h6 {\n				color: #333333;\n			}\n\n			#order_review {\n				background-color: #ffffff;\n			}\n\n			#payment .payment_methods > li .payment_box,\n			#payment .place-order {\n				background-color: #fafafa;\n			}\n\n			#payment .payment_methods > li:not(.woocommerce-notice) {\n				background-color: #f5f5f5;\n			}\n\n			#payment .payment_methods > li:not(.woocommerce-notice):hover {\n				background-color: #f0f0f0;\n			}\n\n			@media screen and ( min-width: 768px ) {\n				.secondary-navigation ul.menu a:hover {\n					color: #868686;\n				}\n\n				.secondary-navigation ul.menu a {\n					color: #6d6d6d;\n				}\n\n				.site-header-cart .widget_shopping_cart,\n				.main-navigation ul.menu ul.sub-menu,\n				.main-navigation ul.nav-menu ul.children {\n					background-color: #f0f0f0;\n				}\n\n				.site-header-cart .widget_shopping_cart .buttons,\n				.site-header-cart .widget_shopping_cart .total {\n					background-color: #f5f5f5;\n				}\n\n				.site-header {\n					border-bottom-color: #f0f0f0;\n				}\n			}\";s:29:\"storefront_woocommerce_styles\";s:2283:\"\n			a.cart-contents,\n			.site-header-cart .widget_shopping_cart a {\n				color: #333333;\n			}\n\n			table.cart td.product-remove,\n			table.cart td.actions {\n				border-top-color: #ffffff;\n			}\n\n			.woocommerce-tabs ul.tabs li.active a,\n			ul.products li.product .price,\n			.onsale,\n			.widget_search form:before,\n			.widget_product_search form:before {\n				color: #6d6d6d;\n			}\n\n			.woocommerce-breadcrumb a,\n			a.woocommerce-review-link,\n			.product_meta a {\n				color: #9f9f9f;\n			}\n\n			.onsale {\n				border-color: #6d6d6d;\n			}\n\n			.star-rating span:before,\n			.quantity .plus, .quantity .minus,\n			p.stars a:hover:after,\n			p.stars a:after,\n			.star-rating span:before,\n			#payment .payment_methods li input[type=radio]:first-child:checked+label:before {\n				color: #96588a;\n			}\n\n			.widget_price_filter .ui-slider .ui-slider-range,\n			.widget_price_filter .ui-slider .ui-slider-handle {\n				background-color: #96588a;\n			}\n\n			.order_details {\n				background-color: #f8f8f8;\n			}\n\n			.order_details > li {\n				border-bottom: 1px dotted #e3e3e3;\n			}\n\n			.order_details:before,\n			.order_details:after {\n				background: -webkit-linear-gradient(transparent 0,transparent 0),-webkit-linear-gradient(135deg,#f8f8f8 33.33{8f2a28b6c580c0cc6b99a4aa3c5c716aadce5613a6846eaa2c7fdf0b7fee70c6},transparent 33.33{8f2a28b6c580c0cc6b99a4aa3c5c716aadce5613a6846eaa2c7fdf0b7fee70c6}),-webkit-linear-gradient(45deg,#f8f8f8 33.33{8f2a28b6c580c0cc6b99a4aa3c5c716aadce5613a6846eaa2c7fdf0b7fee70c6},transparent 33.33{8f2a28b6c580c0cc6b99a4aa3c5c716aadce5613a6846eaa2c7fdf0b7fee70c6})\n			}\n\n			p.stars a:before,\n			p.stars a:hover~a:before,\n			p.stars.selected a.active~a:before {\n				color: #6d6d6d;\n			}\n\n			p.stars.selected a.active:before,\n			p.stars:hover a:before,\n			p.stars.selected a:not(.active):before,\n			p.stars.selected a.active:before {\n				color: #96588a;\n			}\n\n			.single-product div.product .woocommerce-product-gallery .woocommerce-product-gallery__trigger {\n				background-color: #eeeeee;\n				color: #333333;\n			}\n\n			.single-product div.product .woocommerce-product-gallery .woocommerce-product-gallery__trigger:hover {\n				background-color: #d5d5d5;\n				border-color: #d5d5d5;\n				color: #333333;\n			}\n\n			.button.loading {\n				color: #eeeeee;\n			}\n\n			.button.loading:hover {\n				background-color: #eeeeee;\n			}\n\n			.button.loading:after {\n				color: #333333;\n			}\n\n			@media screen and ( min-width: 768px ) {\n				.site-header-cart .widget_shopping_cart,\n				.site-header .product_list_widget li .quantity {\n					color: #6d6d6d;\n				}\n			}\";s:18:\"custom_css_post_id\";i:-1;s:39:\"storefront_woocommerce_extension_styles\";s:0:\"\";s:11:\"custom_logo\";i:18;}","yes");
INSERT INTO wp_options VALUES("150","theme_switched","","yes");
INSERT INTO wp_options VALUES("151","storefront_nux_fresh_site","1","yes");
INSERT INTO wp_options VALUES("154","recently_activated","a:0:{}","yes");
INSERT INTO wp_options VALUES("157","woocommerce_store_address","Rua Emiliano Perneta, 680","yes");
INSERT INTO wp_options VALUES("158","woocommerce_store_address_2","","yes");
INSERT INTO wp_options VALUES("159","woocommerce_store_city","Curitiba","yes");
INSERT INTO wp_options VALUES("160","woocommerce_default_country","BR:PR","yes");
INSERT INTO wp_options VALUES("161","woocommerce_store_postcode","80420080","yes");
INSERT INTO wp_options VALUES("162","woocommerce_allowed_countries","all","yes");
INSERT INTO wp_options VALUES("163","woocommerce_all_except_countries","","yes");
INSERT INTO wp_options VALUES("164","woocommerce_specific_allowed_countries","","yes");
INSERT INTO wp_options VALUES("165","woocommerce_ship_to_countries","","yes");
INSERT INTO wp_options VALUES("166","woocommerce_specific_ship_to_countries","","yes");
INSERT INTO wp_options VALUES("167","woocommerce_default_customer_address","geolocation","yes");
INSERT INTO wp_options VALUES("168","woocommerce_calc_taxes","no","yes");
INSERT INTO wp_options VALUES("169","woocommerce_enable_coupons","yes","yes");
INSERT INTO wp_options VALUES("170","woocommerce_calc_discounts_sequentially","no","no");
INSERT INTO wp_options VALUES("171","woocommerce_currency","BRL","yes");
INSERT INTO wp_options VALUES("172","woocommerce_currency_pos","left","yes");
INSERT INTO wp_options VALUES("173","woocommerce_price_thousand_sep",".","yes");
INSERT INTO wp_options VALUES("174","woocommerce_price_decimal_sep",",","yes");
INSERT INTO wp_options VALUES("175","woocommerce_price_num_decimals","2","yes");
INSERT INTO wp_options VALUES("176","woocommerce_shop_page_id","8","yes");
INSERT INTO wp_options VALUES("177","woocommerce_cart_redirect_after_add","no","yes");
INSERT INTO wp_options VALUES("178","woocommerce_enable_ajax_add_to_cart","yes","yes");
INSERT INTO wp_options VALUES("179","woocommerce_weight_unit","g","yes");
INSERT INTO wp_options VALUES("180","woocommerce_dimension_unit","cm","yes");
INSERT INTO wp_options VALUES("181","woocommerce_enable_reviews","yes","yes");
INSERT INTO wp_options VALUES("182","woocommerce_review_rating_verification_label","yes","no");
INSERT INTO wp_options VALUES("183","woocommerce_review_rating_verification_required","no","no");
INSERT INTO wp_options VALUES("184","woocommerce_enable_review_rating","yes","yes");
INSERT INTO wp_options VALUES("185","woocommerce_review_rating_required","yes","no");
INSERT INTO wp_options VALUES("186","woocommerce_manage_stock","yes","yes");
INSERT INTO wp_options VALUES("187","woocommerce_hold_stock_minutes","60","no");
INSERT INTO wp_options VALUES("188","woocommerce_notify_low_stock","yes","no");
INSERT INTO wp_options VALUES("189","woocommerce_notify_no_stock","yes","no");
INSERT INTO wp_options VALUES("190","woocommerce_stock_email_recipient","hello@bulkdesign.com.br","no");
INSERT INTO wp_options VALUES("191","woocommerce_notify_low_stock_amount","2","no");
INSERT INTO wp_options VALUES("192","woocommerce_notify_no_stock_amount","0","yes");
INSERT INTO wp_options VALUES("193","woocommerce_hide_out_of_stock_items","no","yes");
INSERT INTO wp_options VALUES("194","woocommerce_stock_format","","yes");
INSERT INTO wp_options VALUES("195","woocommerce_file_download_method","force","no");
INSERT INTO wp_options VALUES("196","woocommerce_downloads_require_login","no","no");
INSERT INTO wp_options VALUES("197","woocommerce_downloads_grant_access_after_payment","yes","no");
INSERT INTO wp_options VALUES("198","woocommerce_prices_include_tax","no","yes");
INSERT INTO wp_options VALUES("199","woocommerce_tax_based_on","shipping","yes");
INSERT INTO wp_options VALUES("200","woocommerce_shipping_tax_class","inherit","yes");
INSERT INTO wp_options VALUES("201","woocommerce_tax_round_at_subtotal","no","yes");
INSERT INTO wp_options VALUES("202","woocommerce_tax_classes","Reduced rate\nZero rate","yes");
INSERT INTO wp_options VALUES("203","woocommerce_tax_display_shop","excl","yes");
INSERT INTO wp_options VALUES("204","woocommerce_tax_display_cart","excl","yes");
INSERT INTO wp_options VALUES("205","woocommerce_price_display_suffix","","yes");
INSERT INTO wp_options VALUES("206","woocommerce_tax_total_display","itemized","no");
INSERT INTO wp_options VALUES("207","woocommerce_enable_shipping_calc","yes","no");
INSERT INTO wp_options VALUES("208","woocommerce_shipping_cost_requires_address","no","yes");
INSERT INTO wp_options VALUES("209","woocommerce_ship_to_destination","billing","no");
INSERT INTO wp_options VALUES("210","woocommerce_shipping_debug_mode","no","yes");
INSERT INTO wp_options VALUES("211","woocommerce_enable_guest_checkout","yes","no");
INSERT INTO wp_options VALUES("212","woocommerce_enable_checkout_login_reminder","no","no");
INSERT INTO wp_options VALUES("213","woocommerce_enable_signup_and_login_from_checkout","no","no");
INSERT INTO wp_options VALUES("214","woocommerce_enable_myaccount_registration","no","no");
INSERT INTO wp_options VALUES("215","woocommerce_registration_generate_username","yes","no");
INSERT INTO wp_options VALUES("216","woocommerce_registration_generate_password","yes","no");
INSERT INTO wp_options VALUES("217","woocommerce_erasure_request_removes_order_data","no","no");
INSERT INTO wp_options VALUES("218","woocommerce_erasure_request_removes_download_data","no","no");
INSERT INTO wp_options VALUES("219","woocommerce_registration_privacy_policy_text","Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].","yes");
INSERT INTO wp_options VALUES("220","woocommerce_checkout_privacy_policy_text","Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].","yes");
INSERT INTO wp_options VALUES("221","woocommerce_delete_inactive_accounts","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO wp_options VALUES("222","woocommerce_trash_pending_orders","","no");
INSERT INTO wp_options VALUES("223","woocommerce_trash_failed_orders","","no");
INSERT INTO wp_options VALUES("224","woocommerce_trash_cancelled_orders","","no");
INSERT INTO wp_options VALUES("225","woocommerce_anonymize_completed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO wp_options VALUES("226","woocommerce_email_from_name","CBDMed","no");
INSERT INTO wp_options VALUES("227","woocommerce_email_from_address","hello@bulkdesign.com.br","no");
INSERT INTO wp_options VALUES("228","woocommerce_email_header_image","","no");
INSERT INTO wp_options VALUES("229","woocommerce_email_footer_text","{site_title}","no");
INSERT INTO wp_options VALUES("230","woocommerce_email_base_color","#96588a","no");
INSERT INTO wp_options VALUES("231","woocommerce_email_background_color","#f7f7f7","no");
INSERT INTO wp_options VALUES("232","woocommerce_email_body_background_color","#ffffff","no");
INSERT INTO wp_options VALUES("233","woocommerce_email_text_color","#3c3c3c","no");
INSERT INTO wp_options VALUES("234","woocommerce_cart_page_id","9","yes");
INSERT INTO wp_options VALUES("235","woocommerce_checkout_page_id","10","yes");
INSERT INTO wp_options VALUES("236","woocommerce_myaccount_page_id","11","yes");
INSERT INTO wp_options VALUES("237","woocommerce_terms_page_id","","no");
INSERT INTO wp_options VALUES("238","woocommerce_force_ssl_checkout","no","yes");
INSERT INTO wp_options VALUES("239","woocommerce_unforce_ssl_checkout","no","yes");
INSERT INTO wp_options VALUES("240","woocommerce_checkout_pay_endpoint","order-pay","yes");
INSERT INTO wp_options VALUES("241","woocommerce_checkout_order_received_endpoint","order-received","yes");
INSERT INTO wp_options VALUES("242","woocommerce_myaccount_add_payment_method_endpoint","add-payment-method","yes");
INSERT INTO wp_options VALUES("243","woocommerce_myaccount_delete_payment_method_endpoint","delete-payment-method","yes");
INSERT INTO wp_options VALUES("244","woocommerce_myaccount_set_default_payment_method_endpoint","set-default-payment-method","yes");
INSERT INTO wp_options VALUES("245","woocommerce_myaccount_orders_endpoint","orders","yes");
INSERT INTO wp_options VALUES("246","woocommerce_myaccount_view_order_endpoint","view-order","yes");
INSERT INTO wp_options VALUES("247","woocommerce_myaccount_downloads_endpoint","downloads","yes");
INSERT INTO wp_options VALUES("248","woocommerce_myaccount_edit_account_endpoint","edit-account","yes");
INSERT INTO wp_options VALUES("249","woocommerce_myaccount_edit_address_endpoint","edit-address","yes");
INSERT INTO wp_options VALUES("250","woocommerce_myaccount_payment_methods_endpoint","payment-methods","yes");
INSERT INTO wp_options VALUES("251","woocommerce_myaccount_lost_password_endpoint","lost-password","yes");
INSERT INTO wp_options VALUES("252","woocommerce_logout_endpoint","customer-logout","yes");
INSERT INTO wp_options VALUES("253","woocommerce_api_enabled","no","yes");
INSERT INTO wp_options VALUES("254","woocommerce_single_image_width","600","yes");
INSERT INTO wp_options VALUES("255","woocommerce_thumbnail_image_width","300","yes");
INSERT INTO wp_options VALUES("256","woocommerce_checkout_highlight_required_fields","yes","yes");
INSERT INTO wp_options VALUES("257","woocommerce_demo_store","no","no");
INSERT INTO wp_options VALUES("258","woocommerce_permalinks","a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}","yes");
INSERT INTO wp_options VALUES("259","current_theme_supports_woocommerce","yes","yes");
INSERT INTO wp_options VALUES("260","woocommerce_queue_flush_rewrite_rules","no","yes");
INSERT INTO wp_options VALUES("261","_transient_wc_attribute_taxonomies","a:0:{}","yes");
INSERT INTO wp_options VALUES("262","product_cat_children","a:0:{}","yes");
INSERT INTO wp_options VALUES("263","default_product_cat","15","yes");
INSERT INTO wp_options VALUES("266","woocommerce_version","3.4.3","yes");
INSERT INTO wp_options VALUES("267","woocommerce_db_version","3.4.3","yes");
INSERT INTO wp_options VALUES("268","woocommerce_admin_notices","a:1:{i:3;s:19:\"no_shipping_methods\";}","yes");
INSERT INTO wp_options VALUES("269","storefront_cleared_widgets","1","yes");
INSERT INTO wp_options VALUES("270","_transient_woocommerce_webhook_ids","a:0:{}","yes");
INSERT INTO wp_options VALUES("271","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("272","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("273","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("274","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("275","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("276","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("277","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("278","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("279","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("280","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("281","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("282","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO wp_options VALUES("285","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:0;s:3:\"all\";i:0;s:9:\"moderated\";i:0;s:8:\"approved\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO wp_options VALUES("286","woocommerce_meta_box_errors","a:0:{}","yes");
INSERT INTO wp_options VALUES("292","woocommerce_product_type","physical","yes");
INSERT INTO wp_options VALUES("293","woocommerce_sell_in_person","1","yes");
INSERT INTO wp_options VALUES("294","woocommerce_allow_tracking","no","yes");
INSERT INTO wp_options VALUES("296","woocommerce_ppec_paypal_settings","a:2:{s:16:\"reroute_requests\";b:0;s:5:\"email\";s:23:\"hello@bulkdesign.com.br\";}","yes");
INSERT INTO wp_options VALUES("297","woocommerce_cheque_settings","a:1:{s:7:\"enabled\";s:2:\"no\";}","yes");
INSERT INTO wp_options VALUES("298","woocommerce_bacs_settings","a:1:{s:7:\"enabled\";s:2:\"no\";}","yes");
INSERT INTO wp_options VALUES("299","woocommerce_cod_settings","a:1:{s:7:\"enabled\";s:2:\"no\";}","yes");
INSERT INTO wp_options VALUES("300","woocommerce_admin_notice_ppec_paypal_install_error","WooCommerce PayPal Express Checkout Gateway could not be installed (Não foi possível criar o diretório.). <a href=\"http://localhost/cbdmed/wp-admin/index.php?wc-install-plugin-redirect=woocommerce-gateway-paypal-express-checkout\">Please install it manually by clicking here.</a>","yes");
INSERT INTO wp_options VALUES("301","_transient_shipping-transient-version","1530586763","yes");
INSERT INTO wp_options VALUES("308","_transient_timeout_wc_low_stock_count","1533178763","no");
INSERT INTO wp_options VALUES("309","_transient_wc_low_stock_count","0","no");
INSERT INTO wp_options VALUES("310","_transient_timeout_wc_outofstock_count","1533178763","no");
INSERT INTO wp_options VALUES("311","_transient_wc_outofstock_count","0","no");
INSERT INTO wp_options VALUES("312","storefront_nux_dismissed","1","yes");
INSERT INTO wp_options VALUES("317","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1531282670;s:7:\"checked\";a:8:{s:33:\"admin-menu-editor/menu-editor.php\";s:5:\"1.8.4\";s:30:\"advanced-custom-fields/acf.php\";s:6:\"4.4.12\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.0.2\";s:53:\"contact-form-submissions/contact-form-submissions.php\";s:5:\"1.6.2\";s:43:\"custom-post-type-ui/custom-post-type-ui.php\";s:5:\"1.5.8\";s:26:\"post-smtp/postman-smtp.php\";s:5:\"1.8.9\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.4.3\";s:41:\"wp-database-backup/wp-database-backup.php\";s:3:\"4.6\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:2:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:3:\"5.0\";s:7:\"updated\";s:19:\"2018-02-03 16:12:23\";s:7:\"package\";s:79:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/5.0/pt_BR.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:11:\"woocommerce\";s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"3.4.3\";s:7:\"updated\";s:19:\"2018-06-20 18:12:31\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/plugin/woocommerce/3.4.3/pt_BR.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:8:{s:33:\"admin-menu-editor/menu-editor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/admin-menu-editor\";s:4:\"slug\";s:17:\"admin-menu-editor\";s:6:\"plugin\";s:33:\"admin-menu-editor/menu-editor.php\";s:11:\"new_version\";s:5:\"1.8.4\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/admin-menu-editor/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/admin-menu-editor.1.8.4.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/admin-menu-editor/assets/icon-128x128.png?rev=1418604\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/admin-menu-editor/assets/banner-772x250.png?rev=1419590\";}s:11:\"banners_rtl\";a:0:{}}s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:6:\"4.4.12\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.4.4.12.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.0.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:53:\"contact-form-submissions/contact-form-submissions.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/contact-form-submissions\";s:4:\"slug\";s:24:\"contact-form-submissions\";s:6:\"plugin\";s:53:\"contact-form-submissions/contact-form-submissions.php\";s:11:\"new_version\";s:5:\"1.6.2\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/contact-form-submissions/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/contact-form-submissions.1.6.2.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:77:\"https://ps.w.org/contact-form-submissions/assets/icon-128x128.jpg?rev=1290767\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/contact-form-submissions/assets/banner-772x250.png?rev=1290767\";}s:11:\"banners_rtl\";a:0:{}}s:43:\"custom-post-type-ui/custom-post-type-ui.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/custom-post-type-ui\";s:4:\"slug\";s:19:\"custom-post-type-ui\";s:6:\"plugin\";s:43:\"custom-post-type-ui/custom-post-type-ui.php\";s:11:\"new_version\";s:5:\"1.5.8\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/custom-post-type-ui/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/custom-post-type-ui.1.5.8.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/custom-post-type-ui/assets/icon-256x256.png?rev=1069557\";s:2:\"1x\";s:72:\"https://ps.w.org/custom-post-type-ui/assets/icon-128x128.png?rev=1069557\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/custom-post-type-ui/assets/banner-1544x500.png?rev=1069557\";s:2:\"1x\";s:74:\"https://ps.w.org/custom-post-type-ui/assets/banner-772x250.png?rev=1069557\";}s:11:\"banners_rtl\";a:0:{}}s:26:\"post-smtp/postman-smtp.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:23:\"w.org/plugins/post-smtp\";s:4:\"slug\";s:9:\"post-smtp\";s:6:\"plugin\";s:26:\"post-smtp/postman-smtp.php\";s:11:\"new_version\";s:5:\"1.8.9\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/post-smtp/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/post-smtp.1.8.9.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/post-smtp/assets/icon-128x128.png?rev=1749163\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:64:\"https://ps.w.org/post-smtp/assets/banner-772x250.png?rev=1746638\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.4.3\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.4.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184\";}s:11:\"banners_rtl\";a:0:{}}s:41:\"wp-database-backup/wp-database-backup.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/wp-database-backup\";s:4:\"slug\";s:18:\"wp-database-backup\";s:6:\"plugin\";s:41:\"wp-database-backup/wp-database-backup.php\";s:11:\"new_version\";s:3:\"4.6\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/wp-database-backup/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wp-database-backup.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/wp-database-backup/assets/icon-128x128.png?rev=1456861\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:74:\"https://ps.w.org/wp-database-backup/assets/banner-1544x500.png?rev=1456043\";s:2:\"1x\";s:73:\"https://ps.w.org/wp-database-backup/assets/banner-772x250.png?rev=1456043\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO wp_options VALUES("318","wpcf7","a:2:{s:7:\"version\";s:5:\"5.0.2\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";d:1530575984;s:7:\"version\";s:5:\"5.0.2\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO wp_options VALUES("321","postman_state","a:3:{s:15:\"locking_enabled\";b:1;s:12:\"install_date\";i:1530586784;s:7:\"version\";s:5:\"1.8.9\";}","yes");
INSERT INTO wp_options VALUES("322","ws_menu_editor","a:24:{s:22:\"hide_advanced_settings\";b:1;s:16:\"show_extra_icons\";b:0;s:11:\"custom_menu\";N;s:19:\"custom_network_menu\";N;s:18:\"first_install_time\";i:1530586784;s:21:\"display_survey_notice\";b:1;s:17:\"plugin_db_version\";i:140;s:24:\"security_logging_enabled\";b:0;s:17:\"menu_config_scope\";s:6:\"global\";s:13:\"plugin_access\";s:14:\"manage_options\";s:15:\"allowed_user_id\";N;s:28:\"plugins_page_allowed_user_id\";N;s:27:\"show_deprecated_hide_button\";b:1;s:37:\"dashboard_hiding_confirmation_enabled\";b:1;s:21:\"submenu_icons_enabled\";s:9:\"if_custom\";s:22:\"force_custom_dashicons\";b:1;s:16:\"ui_colour_scheme\";s:7:\"classic\";s:13:\"visible_users\";a:0:{}s:23:\"show_plugin_menu_notice\";b:0;s:20:\"unused_item_position\";s:8:\"relative\";s:23:\"unused_item_permissions\";s:9:\"unchanged\";s:15:\"error_verbosity\";i:2;s:20:\"compress_custom_menu\";b:0;s:16:\"is_active_module\";a:1:{s:19:\"highlight-new-menus\";b:0;}}","yes");
INSERT INTO wp_options VALUES("323","acf_version","4.4.12","yes");
INSERT INTO wp_options VALUES("324","cptui_new_install","false","yes");
INSERT INTO wp_options VALUES("326","_transient_timeout_wc_shipping_method_count_0_1530586763","1533178798","no");
INSERT INTO wp_options VALUES("327","_transient_wc_shipping_method_count_0_1530586763","0","no");
INSERT INTO wp_options VALUES("332","postman_release_version_not_configured","1","yes");
INSERT INTO wp_options VALUES("340","woocommerce_maybe_regenerate_images_hash","991b1ca641921cf0f5baf7a2fe85861b","yes");
INSERT INTO wp_options VALUES("349","wp_db_backup_destination_FTP","1","yes");
INSERT INTO wp_options VALUES("350","wp_db_backup_destination_Email","1","yes");
INSERT INTO wp_options VALUES("351","wp_db_backup_destination_s3","1","yes");
INSERT INTO wp_options VALUES("352","wp_db_remove_local_backup","0","yes");
INSERT INTO wp_options VALUES("356","backupbreeze_ftp_host","ftp.bulkdesign.com.br","yes");
INSERT INTO wp_options VALUES("357","backupbreeze_ftp_user","bulkd420","yes");
INSERT INTO wp_options VALUES("358","backupbreeze_ftp_pass","1Hz_$iQl]Xx(D","yes");
INSERT INTO wp_options VALUES("359","backupbreeze_ftp_subdir","/public_html/cbdmed","yes");
INSERT INTO wp_options VALUES("360","backupbreeze_ftp_port","","yes");
INSERT INTO wp_options VALUES("371","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO wp_options VALUES("441","_transient_timeout_external_ip_address_::1","1531869693","no");
INSERT INTO wp_options VALUES("442","_transient_external_ip_address_::1","177.204.112.78","no");
INSERT INTO wp_options VALUES("451","_site_transient_timeout_theme_roots","1531284471","no");
INSERT INTO wp_options VALUES("452","_site_transient_theme_roots","a:1:{s:10:\"storefront\";s:7:\"/themes\";}","no");
INSERT INTO wp_options VALUES("463","category_children","a:0:{}","yes");
INSERT INTO wp_options VALUES("471","_transient_is_multi_author","0","yes");



CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_postmeta VALUES("12","12","_form","<div class=\"row\">\n<div class=\"col s12\">\n<div class=\"col s12\">\n[text* contato-nome class:validate placeholder \"Digite o seu nome\"]\n</div>\n<div class=\"col s12\">\n[email* contato-email class:validate placeholder \"Digite aqui o seu e-mail\"]\n</div>\n<div class=\"col s12\">\n[text* contato-telefone id:telefone class:validate placeholder \"Insira o seu telefone\"]\n</div>\n<div class=\"col s12\">\n[text* contato-cidade id:cidade class:validate placeholder \"Insira a sua cidade\"]\n</div>\n<div class=\"col s12\">\n[text* contato-assunto class:validate placeholder \"Insira o assunto\"]\n</div>\n<div class=\"col s12\">\n[textarea* contato-mensagem placeholder \"Digite aqui a sua mensagem\"]\n</div>\n<div class=\"col s12 margin20\">\n[submit class:btn \"Enviar\"]\n</div>\n</div>\n</div>");
INSERT INTO wp_postmeta VALUES("13","12","_mail","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:34:\"Contato CDBMED, por [contato-nome]\";s:6:\"sender\";s:40:\"[contato-nome] <hello@bulkdesign.com.br>\";s:9:\"recipient\";s:23:\"hello@bulkdesign.com.br\";s:4:\"body\";s:350:\"De: [contato-nome] <[contato-email]>\nAssunto: Contato CDBMED, por [contato-nome] - \"[contato-assunto]\"\n\nOlá! Uma pessoa entrou em contato através do formulário do site:\n\nNome: [contato-nome]\nTelefone: [contato-telefone]\nCidade: [contato-cidade]\nAssunto: [contato-assunto]\nMensagem: [contato-mensagem]\n\n-- \nEste e-mail foi enviado pelo site CDBMed.\";s:18:\"additional_headers\";s:25:\"Reply-To: [contato-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO wp_postmeta VALUES("14","12","_mail_2","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:46:\"Equipe CDBMED - Obrigado por entrar em contato\";s:6:\"sender\";s:39:\"Equipe CBDMED <hello@bulkdesign.com.br>\";s:9:\"recipient\";s:15:\"[contato-email]\";s:4:\"body\";s:161:\"Olá, [contato-nome]! Obrigado por entrar em contato conosco.\n\nNós recebemos o seu e-mail e em breve nós lhe responderemos.\n\n---\nAtenciosamente,\nEquipe CDBMED.\";s:18:\"additional_headers\";s:33:\"Reply-To: hello@bulkdesign.com.br\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO wp_postmeta VALUES("15","12","_messages","a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}");
INSERT INTO wp_postmeta VALUES("16","12","_additional_settings","");
INSERT INTO wp_postmeta VALUES("17","12","_locale","pt_BR");
INSERT INTO wp_postmeta VALUES("19","14","_edit_last","1");
INSERT INTO wp_postmeta VALUES("20","14","_wp_page_template","page-home.php");
INSERT INTO wp_postmeta VALUES("21","14","_edit_lock","1530586865:1");
INSERT INTO wp_postmeta VALUES("23","16","_wp_trash_meta_status","publish");
INSERT INTO wp_postmeta VALUES("24","16","_wp_trash_meta_time","1530587005");
INSERT INTO wp_postmeta VALUES("25","17","_wp_attached_file","2018/07/logo.png");
INSERT INTO wp_postmeta VALUES("26","17","_wp_attachment_metadata","a:5:{s:5:\"width\";i:228;s:6:\"height\";i:45;s:4:\"file\";s:16:\"2018/07/logo.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-150x45.png\";s:5:\"width\";i:150;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-100x45.png\";s:5:\"width\";i:100;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-100x45.png\";s:5:\"width\";i:100;s:6:\"height\";i:45;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO wp_postmeta VALUES("27","18","_wp_attached_file","2018/07/cropped-logo.png");
INSERT INTO wp_postmeta VALUES("28","18","_wp_attachment_context","custom-logo");
INSERT INTO wp_postmeta VALUES("29","18","_wp_attachment_metadata","a:5:{s:5:\"width\";i:557;s:6:\"height\";i:110;s:4:\"file\";s:24:\"2018/07/cropped-logo.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"cropped-logo-150x110.png\";s:5:\"width\";i:150;s:6:\"height\";i:110;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"cropped-logo-300x59.png\";s:5:\"width\";i:300;s:6:\"height\";i:59;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"cropped-logo-300x110.png\";s:5:\"width\";i:300;s:6:\"height\";i:110;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"cropped-logo-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:24:\"cropped-logo-300x110.png\";s:5:\"width\";i:300;s:6:\"height\";i:110;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"cropped-logo-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO wp_postmeta VALUES("30","19","_wp_trash_meta_status","publish");
INSERT INTO wp_postmeta VALUES("31","19","_wp_trash_meta_time","1530587335");
INSERT INTO wp_postmeta VALUES("32","20","_menu_item_type","custom");
INSERT INTO wp_postmeta VALUES("33","20","_menu_item_menu_item_parent","0");
INSERT INTO wp_postmeta VALUES("34","20","_menu_item_object_id","20");
INSERT INTO wp_postmeta VALUES("35","20","_menu_item_object","custom");
INSERT INTO wp_postmeta VALUES("36","20","_menu_item_target","");
INSERT INTO wp_postmeta VALUES("37","20","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO wp_postmeta VALUES("38","20","_menu_item_xfn","");
INSERT INTO wp_postmeta VALUES("39","20","_menu_item_url","/cbdmed");
INSERT INTO wp_postmeta VALUES("41","21","_menu_item_type","custom");
INSERT INTO wp_postmeta VALUES("42","21","_menu_item_menu_item_parent","0");
INSERT INTO wp_postmeta VALUES("43","21","_menu_item_object_id","21");
INSERT INTO wp_postmeta VALUES("44","21","_menu_item_object","custom");
INSERT INTO wp_postmeta VALUES("45","21","_menu_item_target","");
INSERT INTO wp_postmeta VALUES("46","21","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO wp_postmeta VALUES("47","21","_menu_item_xfn","");
INSERT INTO wp_postmeta VALUES("48","21","_menu_item_url","/cbdmed#oquee");
INSERT INTO wp_postmeta VALUES("50","22","_menu_item_type","custom");
INSERT INTO wp_postmeta VALUES("51","22","_menu_item_menu_item_parent","0");
INSERT INTO wp_postmeta VALUES("52","22","_menu_item_object_id","22");
INSERT INTO wp_postmeta VALUES("53","22","_menu_item_object","custom");
INSERT INTO wp_postmeta VALUES("54","22","_menu_item_target","");
INSERT INTO wp_postmeta VALUES("55","22","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO wp_postmeta VALUES("56","22","_menu_item_xfn","");
INSERT INTO wp_postmeta VALUES("57","22","_menu_item_url","/cbdmed#paraqueserve");
INSERT INTO wp_postmeta VALUES("104","28","_edit_last","1");
INSERT INTO wp_postmeta VALUES("105","28","_edit_lock","1530938915:1");
INSERT INTO wp_postmeta VALUES("106","28","_wp_page_template","page-comocomprar.php");
INSERT INTO wp_postmeta VALUES("107","30","_menu_item_type","post_type");
INSERT INTO wp_postmeta VALUES("108","30","_menu_item_menu_item_parent","0");
INSERT INTO wp_postmeta VALUES("109","30","_menu_item_object_id","28");
INSERT INTO wp_postmeta VALUES("110","30","_menu_item_object","page");
INSERT INTO wp_postmeta VALUES("111","30","_menu_item_target","");
INSERT INTO wp_postmeta VALUES("112","30","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO wp_postmeta VALUES("113","30","_menu_item_xfn","");
INSERT INTO wp_postmeta VALUES("114","30","_menu_item_url","");
INSERT INTO wp_postmeta VALUES("116","31","_edit_last","1");
INSERT INTO wp_postmeta VALUES("117","31","_edit_lock","1531027798:1");
INSERT INTO wp_postmeta VALUES("118","31","_wp_page_template","page-medicos.php");
INSERT INTO wp_postmeta VALUES("119","33","_menu_item_type","post_type");
INSERT INTO wp_postmeta VALUES("120","33","_menu_item_menu_item_parent","0");
INSERT INTO wp_postmeta VALUES("121","33","_menu_item_object_id","31");
INSERT INTO wp_postmeta VALUES("122","33","_menu_item_object","page");
INSERT INTO wp_postmeta VALUES("123","33","_menu_item_target","");
INSERT INTO wp_postmeta VALUES("124","33","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO wp_postmeta VALUES("125","33","_menu_item_xfn","");
INSERT INTO wp_postmeta VALUES("126","33","_menu_item_url","");
INSERT INTO wp_postmeta VALUES("128","34","_edit_last","1");
INSERT INTO wp_postmeta VALUES("129","34","_wp_page_template","page-produtos.php");
INSERT INTO wp_postmeta VALUES("130","34","_edit_lock","1531027819:1");
INSERT INTO wp_postmeta VALUES("131","36","_menu_item_type","post_type");
INSERT INTO wp_postmeta VALUES("132","36","_menu_item_menu_item_parent","0");
INSERT INTO wp_postmeta VALUES("133","36","_menu_item_object_id","34");
INSERT INTO wp_postmeta VALUES("134","36","_menu_item_object","page");
INSERT INTO wp_postmeta VALUES("135","36","_menu_item_target","");
INSERT INTO wp_postmeta VALUES("136","36","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO wp_postmeta VALUES("137","36","_menu_item_xfn","");
INSERT INTO wp_postmeta VALUES("138","36","_menu_item_url","");
INSERT INTO wp_postmeta VALUES("139","37","_edit_last","1");
INSERT INTO wp_postmeta VALUES("140","37","_edit_lock","1531283377:1");
INSERT INTO wp_postmeta VALUES("141","37","_wp_page_template","page-contato.php");
INSERT INTO wp_postmeta VALUES("142","39","_menu_item_type","post_type");
INSERT INTO wp_postmeta VALUES("143","39","_menu_item_menu_item_parent","0");
INSERT INTO wp_postmeta VALUES("144","39","_menu_item_object_id","37");
INSERT INTO wp_postmeta VALUES("145","39","_menu_item_object","page");
INSERT INTO wp_postmeta VALUES("146","39","_menu_item_target","");
INSERT INTO wp_postmeta VALUES("147","39","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO wp_postmeta VALUES("148","39","_menu_item_xfn","");
INSERT INTO wp_postmeta VALUES("149","39","_menu_item_url","");
INSERT INTO wp_postmeta VALUES("153","40","_edit_last","1");
INSERT INTO wp_postmeta VALUES("154","40","_edit_lock","1531285851:1");
INSERT INTO wp_postmeta VALUES("155","40","_wp_page_template","page-noticias.php");
INSERT INTO wp_postmeta VALUES("156","42","_menu_item_type","post_type");
INSERT INTO wp_postmeta VALUES("157","42","_menu_item_menu_item_parent","0");
INSERT INTO wp_postmeta VALUES("158","42","_menu_item_object_id","40");
INSERT INTO wp_postmeta VALUES("159","42","_menu_item_object","page");
INSERT INTO wp_postmeta VALUES("160","42","_menu_item_target","");
INSERT INTO wp_postmeta VALUES("161","42","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO wp_postmeta VALUES("162","42","_menu_item_xfn","");
INSERT INTO wp_postmeta VALUES("163","42","_menu_item_url","");
INSERT INTO wp_postmeta VALUES("165","43","_edit_last","1");
INSERT INTO wp_postmeta VALUES("166","43","_edit_lock","1531289450:1");
INSERT INTO wp_postmeta VALUES("167","44","_wp_attached_file","2018/07/super_imgvdd-sobre-maconha.jpg");
INSERT INTO wp_postmeta VALUES("168","44","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:600;s:4:\"file\";s:38:\"2018/07/super_imgvdd-sobre-maconha.jpg\";s:5:\"sizes\";a:9:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-600x450.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-600x450.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:450;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:38:\"super_imgvdd-sobre-maconha-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO wp_postmeta VALUES("169","43","_thumbnail_id","44");
INSERT INTO wp_postmeta VALUES("171","46","_edit_last","1");
INSERT INTO wp_postmeta VALUES("172","46","_edit_lock","1531289447:1");
INSERT INTO wp_postmeta VALUES("173","47","_wp_attached_file","2018/07/doenca-de-parkinson-1024x512.jpg");
INSERT INTO wp_postmeta VALUES("174","47","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:512;s:4:\"file\";s:40:\"2018/07/doenca-de-parkinson-1024x512.jpg\";s:5:\"sizes\";a:10:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-300x150.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-768x384.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:384;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:41:\"doenca-de-parkinson-1024x512-1024x512.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-600x300.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-600x300.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:40:\"doenca-de-parkinson-1024x512-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO wp_postmeta VALUES("175","46","_thumbnail_id","47");
INSERT INTO wp_postmeta VALUES("177","49","_edit_last","1");
INSERT INTO wp_postmeta VALUES("178","49","_edit_lock","1531289666:1");
INSERT INTO wp_postmeta VALUES("179","49","_wp_page_template","default");
INSERT INTO wp_postmeta VALUES("180","51","_edit_last","1");
INSERT INTO wp_postmeta VALUES("181","51","_edit_lock","1531289719:1");
INSERT INTO wp_postmeta VALUES("182","51","_wp_page_template","default");
INSERT INTO wp_postmeta VALUES("183","53","_edit_last","1");
INSERT INTO wp_postmeta VALUES("184","53","_edit_lock","1531289901:1");
INSERT INTO wp_postmeta VALUES("185","53","_wp_page_template","default");



CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_posts VALUES("8","1","2018-07-02 23:58:28","2018-07-03 02:58:28","","Shop","","publish","closed","closed","","shop","","","2018-07-02 23:58:28","2018-07-03 02:58:28","","0","http://localhost/cbdmed/?page_id=8","0","page","","0");
INSERT INTO wp_posts VALUES("9","1","2018-07-02 23:58:28","2018-07-03 02:58:28","[woocommerce_cart]","Cart","","publish","closed","closed","","cart","","","2018-07-02 23:58:28","2018-07-03 02:58:28","","0","http://localhost/cbdmed/?page_id=9","0","page","","0");
INSERT INTO wp_posts VALUES("10","1","2018-07-02 23:58:28","2018-07-03 02:58:28","[woocommerce_checkout]","Checkout","","publish","closed","closed","","checkout","","","2018-07-02 23:58:28","2018-07-03 02:58:28","","0","http://localhost/cbdmed/?page_id=10","0","page","","0");
INSERT INTO wp_posts VALUES("11","1","2018-07-02 23:58:28","2018-07-03 02:58:28","[woocommerce_my_account]","My account","","publish","closed","closed","","my-account","","","2018-07-02 23:58:28","2018-07-03 02:58:28","","0","http://localhost/cbdmed/?page_id=11","0","page","","0");
INSERT INTO wp_posts VALUES("12","1","2018-07-02 23:59:44","2018-07-03 02:59:44","<div class=\"row\">\r\n<div class=\"col s12\">\r\n<div class=\"col s12\">\r\n[text* contato-nome class:validate placeholder \"Digite o seu nome\"]\r\n</div>\r\n<div class=\"col s12\">\r\n[email* contato-email class:validate placeholder \"Digite aqui o seu e-mail\"]\r\n</div>\r\n<div class=\"col s12\">\r\n[text* contato-telefone id:telefone class:validate placeholder \"Insira o seu telefone\"]\r\n</div>\r\n<div class=\"col s12\">\r\n[text* contato-cidade id:cidade class:validate placeholder \"Insira a sua cidade\"]\r\n</div>\r\n<div class=\"col s12\">\r\n[text* contato-assunto class:validate placeholder \"Insira o assunto\"]\r\n</div>\r\n<div class=\"col s12\">\r\n[textarea* contato-mensagem placeholder \"Digite aqui a sua mensagem\"]\r\n</div>\r\n<div class=\"col s12 margin20\">\r\n[submit class:btn \"Enviar\"]\r\n</div>\r\n</div>\r\n</div>\n1\nContato CDBMED, por [contato-nome]\n[contato-nome] <hello@bulkdesign.com.br>\nhello@bulkdesign.com.br\nDe: [contato-nome] <[contato-email]>\r\nAssunto: Contato CDBMED, por [contato-nome] - \"[contato-assunto]\"\r\n\r\nOlá! Uma pessoa entrou em contato através do formulário do site:\r\n\r\nNome: [contato-nome]\r\nTelefone: [contato-telefone]\r\nCidade: [contato-cidade]\r\nAssunto: [contato-assunto]\r\nMensagem: [contato-mensagem]\r\n\r\n-- \r\nEste e-mail foi enviado pelo site CDBMed.\nReply-To: [contato-email]\n\n\n\n1\nEquipe CDBMED - Obrigado por entrar em contato\nEquipe CBDMED <hello@bulkdesign.com.br>\n[contato-email]\nOlá, [contato-nome]! Obrigado por entrar em contato conosco.\r\n\r\nNós recebemos o seu e-mail e em breve nós lhe responderemos.\r\n\r\n---\r\nAtenciosamente,\r\nEquipe CDBMED.\nReply-To: hello@bulkdesign.com.br\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.","Formulário de Contato","","publish","closed","closed","","contact-form-1","","","2018-07-11 01:58:19","2018-07-11 04:58:19","","0","http://localhost/cbdmed/?post_type=wpcf7_contact_form&#038;p=12","0","wpcf7_contact_form","","0");
INSERT INTO wp_posts VALUES("14","1","2018-07-03 00:02:58","2018-07-03 03:02:58","","Página Inicial","","publish","closed","closed","","pagina-inicial","","","2018-07-03 00:02:58","2018-07-03 03:02:58","","0","http://localhost/cbdmed/?page_id=14","0","page","","0");
INSERT INTO wp_posts VALUES("15","1","2018-07-03 00:02:58","2018-07-03 03:02:58","","Página Inicial","","inherit","closed","closed","","14-revision-v1","","","2018-07-03 00:02:58","2018-07-03 03:02:58","","14","http://localhost/cbdmed/?p=15","0","revision","","0");
INSERT INTO wp_posts VALUES("16","1","2018-07-03 00:03:24","2018-07-03 03:03:24","{\n    \"show_on_front\": {\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-07-03 03:03:24\"\n    },\n    \"page_on_front\": {\n        \"value\": \"14\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-07-03 03:03:24\"\n    }\n}","","","trash","closed","closed","","c9e1bd14-9c18-4e3f-80c0-2e892bde911a","","","2018-07-03 00:03:24","2018-07-03 03:03:24","","0","http://localhost/cbdmed/?p=16","0","customize_changeset","","0");
INSERT INTO wp_posts VALUES("17","1","2018-07-03 00:08:39","2018-07-03 03:08:39","","logo","","inherit","closed","closed","","logo","","","2018-07-03 00:08:39","2018-07-03 03:08:39","","0","http://localhost/cbdmed/wp-content/uploads/2018/07/logo.png","0","attachment","image/png","0");
INSERT INTO wp_posts VALUES("18","1","2018-07-03 00:08:51","2018-07-03 03:08:51","http://localhost/cbdmed/wp-content/uploads/2018/07/cropped-logo.png","cropped-logo.png","","inherit","closed","closed","","cropped-logo-png","","","2018-07-03 00:08:51","2018-07-03 03:08:51","","0","http://localhost/cbdmed/wp-content/uploads/2018/07/cropped-logo.png","0","attachment","image/png","0");
INSERT INTO wp_posts VALUES("19","1","2018-07-03 00:08:55","2018-07-03 03:08:55","{\n    \"storefront::custom_logo\": {\n        \"value\": 18,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-07-03 03:08:55\"\n    }\n}","","","trash","closed","closed","","181f5c51-43ec-475d-af40-c1286f7232d0","","","2018-07-03 00:08:55","2018-07-03 03:08:55","","0","http://localhost/cbdmed/?p=19","0","customize_changeset","","0");
INSERT INTO wp_posts VALUES("20","1","2018-07-04 00:57:34","2018-07-04 03:57:34","","HOME","","publish","closed","closed","","home","","","2018-07-11 02:13:12","2018-07-11 05:13:12","","0","http://localhost/cbdmed/?p=20","1","nav_menu_item","","0");
INSERT INTO wp_posts VALUES("21","1","2018-07-04 00:57:34","2018-07-04 03:57:34","","O QUE É","","publish","closed","closed","","o-que-e","","","2018-07-11 02:13:12","2018-07-11 05:13:12","","0","http://localhost/cbdmed/?p=21","2","nav_menu_item","","0");
INSERT INTO wp_posts VALUES("22","1","2018-07-04 00:57:34","2018-07-04 03:57:34","","PARA QUE SERVE","","publish","closed","closed","","para-que-serve","","","2018-07-11 02:13:12","2018-07-11 05:13:12","","0","http://localhost/cbdmed/?p=22","3","nav_menu_item","","0");
INSERT INTO wp_posts VALUES("28","1","2018-07-07 00:11:08","2018-07-07 03:11:08","","Como Comprar","","publish","closed","closed","","como-comprar","","","2018-07-07 00:11:12","2018-07-07 03:11:12","","0","http://localhost/cbdmed/?page_id=28","0","page","","0");
INSERT INTO wp_posts VALUES("29","1","2018-07-07 00:11:08","2018-07-07 03:11:08","","Como Comprar","","inherit","closed","closed","","28-revision-v1","","","2018-07-07 00:11:08","2018-07-07 03:11:08","","28","http://localhost/cbdmed/?p=29","0","revision","","0");
INSERT INTO wp_posts VALUES("30","1","2018-07-07 00:11:47","2018-07-07 03:11:47","","COMO COMPRAR","","publish","closed","closed","","como-comprar-2","","","2018-07-11 02:13:12","2018-07-11 05:13:12","","0","http://localhost/cbdmed/?p=30","4","nav_menu_item","","0");
INSERT INTO wp_posts VALUES("31","1","2018-07-07 12:35:37","2018-07-07 15:35:37","","Médicos","","publish","closed","closed","","medicos","","","2018-07-07 12:35:37","2018-07-07 15:35:37","","0","http://localhost/cbdmed/?page_id=31","0","page","","0");
INSERT INTO wp_posts VALUES("32","1","2018-07-07 12:35:37","2018-07-07 15:35:37","","Médicos","","inherit","closed","closed","","31-revision-v1","","","2018-07-07 12:35:37","2018-07-07 15:35:37","","31","http://localhost/cbdmed/?p=32","0","revision","","0");
INSERT INTO wp_posts VALUES("33","1","2018-07-07 12:36:02","2018-07-07 15:36:02","","MÉDICOS","","publish","closed","closed","","medicos-2","","","2018-07-11 02:13:12","2018-07-11 05:13:12","","0","http://localhost/cbdmed/?p=33","5","nav_menu_item","","0");
INSERT INTO wp_posts VALUES("34","1","2018-07-08 02:32:32","2018-07-08 05:32:32","","Produtos","","publish","closed","closed","","produtos","","","2018-07-08 02:32:32","2018-07-08 05:32:32","","0","http://localhost/cbdmed/?page_id=34","0","page","","0");
INSERT INTO wp_posts VALUES("35","1","2018-07-08 02:32:32","2018-07-08 05:32:32","","Produtos","","inherit","closed","closed","","34-revision-v1","","","2018-07-08 02:32:32","2018-07-08 05:32:32","","34","http://localhost/cbdmed/?p=35","0","revision","","0");
INSERT INTO wp_posts VALUES("36","1","2018-07-08 02:33:03","2018-07-08 05:33:03","","PRODUTOS","","publish","closed","closed","","produtos-2","","","2018-07-11 02:13:12","2018-07-11 05:13:12","","0","http://localhost/cbdmed/?p=36","6","nav_menu_item","","0");
INSERT INTO wp_posts VALUES("37","1","2018-07-11 01:31:50","2018-07-11 04:31:50","","Contato","","publish","closed","closed","","contato","","","2018-07-11 01:31:50","2018-07-11 04:31:50","","0","http://localhost/cbdmed/?page_id=37","0","page","","0");
INSERT INTO wp_posts VALUES("38","1","2018-07-11 01:31:50","2018-07-11 04:31:50","","Contato","","inherit","closed","closed","","37-revision-v1","","","2018-07-11 01:31:50","2018-07-11 04:31:50","","37","http://localhost/cbdmed/?p=38","0","revision","","0");
INSERT INTO wp_posts VALUES("39","1","2018-07-11 01:32:20","2018-07-11 04:32:20","","CONTATO","","publish","closed","closed","","contato-2","","","2018-07-11 02:13:12","2018-07-11 05:13:12","","0","http://localhost/cbdmed/?p=39","8","nav_menu_item","","0");
INSERT INTO wp_posts VALUES("40","1","2018-07-11 02:12:06","2018-07-11 05:12:06","","Notícias","","publish","closed","closed","","noticias","","","2018-07-11 02:12:06","2018-07-11 05:12:06","","0","http://localhost/cbdmed/?page_id=40","0","page","","0");
INSERT INTO wp_posts VALUES("41","1","2018-07-11 02:12:06","2018-07-11 05:12:06","","Notícias","","inherit","closed","closed","","40-revision-v1","","","2018-07-11 02:12:06","2018-07-11 05:12:06","","40","http://localhost/cbdmed/?p=41","0","revision","","0");
INSERT INTO wp_posts VALUES("42","1","2018-07-11 02:13:12","2018-07-11 05:13:12","","NOTÍCIAS","","publish","closed","closed","","noticias-2","","","2018-07-11 02:13:12","2018-07-11 05:13:12","","0","http://localhost/cbdmed/?p=42","7","nav_menu_item","","0");
INSERT INTO wp_posts VALUES("43","1","2018-07-11 02:16:30","2018-07-11 05:16:30","Cada organismo reage de forma diferente à administração de qualquer substância; não seria diferente com a cannabis. O que vem sendo descoberto com a evolução dos estudos é que o gênero pode desempenhar um papel importante nessa situação. Os hormônios sexuais, a quantidade de receptores cannabinóides e os locais do corpo em que eles são encontrados no corpo diferem entre homens e mulheres, e os pesquisadores seguem descobrindo outras diferenças.\r\n\r\nNo caso específico relacionado aos hormônios sexuais, que são uma grande parte do motivo pelo qual cada gênero experimenta a maconha de sua própria maneira, o estrogênio desempenha um papel particularmente significativo no organismo feminino.\r\n\r\nO estrogênio regula um ácido que degrada um endocanabinóide chamado anandamida, que é a versão natural do corpo do THC, composto presente na maconha e conhecido por seus efeitos eufóricos e capacidade de regulação de humor e apetite. Ao longo do ciclo menstrual, os níveis de estrogênio flutuam bastante, tendo seu menor registro durante o período da menstruação. Quando existe essa baixa do nível, o ácido é capaz de degradar ainda mais livremente a andamida, o que resulta, em muitos casos, em estados temporários de ansiedade e depressão. Muitas mulheres, inclusive, relatam que a maconha é menos efetiva nesse período.\r\n\r\nJá para os indivíduos do sexo masculino, os efeitos da maconha no sistema endocanabinóide não flutuam dessa maneira e em qualquer momento do mês eles sintetizam e afetam os homens da mesma maneira.\r\n\r\nOutra diferença importante que vem sendo encontrada é que, de acordo com um estudo da Universidade do Estado de Washington, as mulheres ficam tolerantes à substância com mais rapidez, o que significa que vale a pena para as mulheres se limparem da droga com mais frequência do que os homens para baixar novamente essa tolerância e não ficar precisando sempre de mais quantidade da maconha para sentir efeitos desejados.","A Maconha afeta homens e mulheres de maneiras diferentes","","publish","closed","closed","","a-maconha-afeta-homens-e-mulheres-de-maneiras-diferentes","","","2018-07-11 02:16:30","2018-07-11 05:16:30","","0","http://localhost/cbdmed/?p=43","0","post","","0");
INSERT INTO wp_posts VALUES("44","1","2018-07-11 02:16:26","2018-07-11 05:16:26","","super_imgvdd-sobre-maconha","","inherit","closed","closed","","super_imgvdd-sobre-maconha","","","2018-07-11 02:16:26","2018-07-11 05:16:26","","43","http://localhost/cbdmed/wp-content/uploads/2018/07/super_imgvdd-sobre-maconha.jpg","0","attachment","image/jpeg","0");
INSERT INTO wp_posts VALUES("45","1","2018-07-11 02:16:30","2018-07-11 05:16:30","Cada organismo reage de forma diferente à administração de qualquer substância; não seria diferente com a cannabis. O que vem sendo descoberto com a evolução dos estudos é que o gênero pode desempenhar um papel importante nessa situação. Os hormônios sexuais, a quantidade de receptores cannabinóides e os locais do corpo em que eles são encontrados no corpo diferem entre homens e mulheres, e os pesquisadores seguem descobrindo outras diferenças.\r\n\r\nNo caso específico relacionado aos hormônios sexuais, que são uma grande parte do motivo pelo qual cada gênero experimenta a maconha de sua própria maneira, o estrogênio desempenha um papel particularmente significativo no organismo feminino.\r\n\r\nO estrogênio regula um ácido que degrada um endocanabinóide chamado anandamida, que é a versão natural do corpo do THC, composto presente na maconha e conhecido por seus efeitos eufóricos e capacidade de regulação de humor e apetite. Ao longo do ciclo menstrual, os níveis de estrogênio flutuam bastante, tendo seu menor registro durante o período da menstruação. Quando existe essa baixa do nível, o ácido é capaz de degradar ainda mais livremente a andamida, o que resulta, em muitos casos, em estados temporários de ansiedade e depressão. Muitas mulheres, inclusive, relatam que a maconha é menos efetiva nesse período.\r\n\r\nJá para os indivíduos do sexo masculino, os efeitos da maconha no sistema endocanabinóide não flutuam dessa maneira e em qualquer momento do mês eles sintetizam e afetam os homens da mesma maneira.\r\n\r\nOutra diferença importante que vem sendo encontrada é que, de acordo com um estudo da Universidade do Estado de Washington, as mulheres ficam tolerantes à substância com mais rapidez, o que significa que vale a pena para as mulheres se limparem da droga com mais frequência do que os homens para baixar novamente essa tolerância e não ficar precisando sempre de mais quantidade da maconha para sentir efeitos desejados.","A Maconha afeta homens e mulheres de maneiras diferentes","","inherit","closed","closed","","43-revision-v1","","","2018-07-11 02:16:30","2018-07-11 05:16:30","","43","http://localhost/cbdmed/?p=45","0","revision","","0");
INSERT INTO wp_posts VALUES("46","1","2018-07-11 03:13:07","2018-07-11 06:13:07","A Doença de Parkinson é uma condição neurodegenerativa crônica e progressiva que ocorre, na maioria das vezes, em pessoas acima dos 65 anos e vai, aos poucos, destruindo neurônios – que são células do nosso organismo que, ao contrário das demais, não têm capacidade de regeneração. Os pacientes com Mal de Parkinson sofrem degeneração em uma região específica do cérebro, causando a deficiência da dopamina, neurotransmissor que possui a função de controlar os movimentos finos. É dessa forma que a doença afeta, entre outras funções, a do movimento, do controle muscular e do equilíbrio.\r\n\r\nAté hoje o Mal de Parkinson não possui cura e nem formas de prevenção recomendadas. Existem alguns tratamentos disponíveis para controlar e amenizar os sintomas, e, recentemente, a maconha medicinal vêm recebido muita atenção como uma terapia alternativa bastante indicada para essa doença.\r\n\r\nOs efeitos da utilização de cannabis sobre a doença de Parkinson já foram bem documentados. A substância tem o potencial de trabalhar como um agente neuroprotetor, catalisando a função das mitocôndrias. Há relatos de pessoas que lutaram contra a doença utilizando o óleo de cannabis, que ajudou muito na contenção dos tremores.\r\n\r\nEm um estudo recente realizado pelo NIH, os resultados apontaram a eficácia do medicamento. De acordo com ele, 22 pacientes tiveram resultados favoráveis nos ensaios clínicos realizados em 2011 e 2012. As pontuações totais dos usuários da cannabis no Exame Motor da Escala Unificada de Avaliação da Doença de Parkinson melhoraram significativamente após o início do consumo da substância. Essas análises revelaram uma melhora significativa nos tremores e nos índices de dor e sono. A conclusão sugeriu então que a substância pode ter um efeito terapêutico bem significativo sobre a doença, mas mais pesquisas devem ser realizadas para estudar os efeitos a longo prazo da utilização da maconha medicinal nesse caso específico.","A Maconha medicinal e seu uso no Mal de Parkinson","","publish","closed","closed","","a-maconha-medicinal-e-seu-uso-no-mal-de-parkinson","","","2018-07-11 03:13:07","2018-07-11 06:13:07","","0","http://localhost/cbdmed/?p=46","0","post","","0");
INSERT INTO wp_posts VALUES("47","1","2018-07-11 03:12:43","2018-07-11 06:12:43","","doenca-de-parkinson-1024x512","","inherit","closed","closed","","doenca-de-parkinson-1024x512","","","2018-07-11 03:12:43","2018-07-11 06:12:43","","46","http://localhost/cbdmed/wp-content/uploads/2018/07/doenca-de-parkinson-1024x512.jpg","0","attachment","image/jpeg","0");
INSERT INTO wp_posts VALUES("48","1","2018-07-11 03:13:07","2018-07-11 06:13:07","A Doença de Parkinson é uma condição neurodegenerativa crônica e progressiva que ocorre, na maioria das vezes, em pessoas acima dos 65 anos e vai, aos poucos, destruindo neurônios – que são células do nosso organismo que, ao contrário das demais, não têm capacidade de regeneração. Os pacientes com Mal de Parkinson sofrem degeneração em uma região específica do cérebro, causando a deficiência da dopamina, neurotransmissor que possui a função de controlar os movimentos finos. É dessa forma que a doença afeta, entre outras funções, a do movimento, do controle muscular e do equilíbrio.\r\n\r\nAté hoje o Mal de Parkinson não possui cura e nem formas de prevenção recomendadas. Existem alguns tratamentos disponíveis para controlar e amenizar os sintomas, e, recentemente, a maconha medicinal vêm recebido muita atenção como uma terapia alternativa bastante indicada para essa doença.\r\n\r\nOs efeitos da utilização de cannabis sobre a doença de Parkinson já foram bem documentados. A substância tem o potencial de trabalhar como um agente neuroprotetor, catalisando a função das mitocôndrias. Há relatos de pessoas que lutaram contra a doença utilizando o óleo de cannabis, que ajudou muito na contenção dos tremores.\r\n\r\nEm um estudo recente realizado pelo NIH, os resultados apontaram a eficácia do medicamento. De acordo com ele, 22 pacientes tiveram resultados favoráveis nos ensaios clínicos realizados em 2011 e 2012. As pontuações totais dos usuários da cannabis no Exame Motor da Escala Unificada de Avaliação da Doença de Parkinson melhoraram significativamente após o início do consumo da substância. Essas análises revelaram uma melhora significativa nos tremores e nos índices de dor e sono. A conclusão sugeriu então que a substância pode ter um efeito terapêutico bem significativo sobre a doença, mas mais pesquisas devem ser realizadas para estudar os efeitos a longo prazo da utilização da maconha medicinal nesse caso específico.","A Maconha medicinal e seu uso no Mal de Parkinson","","inherit","closed","closed","","46-revision-v1","","","2018-07-11 03:13:07","2018-07-11 06:13:07","","46","http://localhost/cbdmed/?p=48","0","revision","","0");
INSERT INTO wp_posts VALUES("49","1","2018-07-11 03:15:16","2018-07-11 06:15:16","MPORTANTE! ESTAS CONDIÇÕES DE SERVIÇO (CdS) GOVERNAM O USO DESTA PÁGINA, A QUAL É FORNECIDA POR NOSSA EMPRESA. AO ACESSAR ESTA PÁGINA VOCÊ CONFIRMA QUE CONHECE E ACEITA ESTAS CONDIÇÕES, AS QUAIS ESTÃO SUJEITAS A ALTERAÇÕES A QUALQUER MOMENTO POR PARTE DE NOSSA EMPRESA. A UTILIZAÇÃO DESTA PÁGINA APÓS A IMPLEMENTAÇÃO DE TAIS ALTERAÇÕES CONFIGURA SEU RECONHECIMENTO E ACEITAÇÃO DAS MESMAS. CONSULTE ESTES TERMOS DE USO REGULARMENTE\r\n<h4><b>Acesso a esta página</b></h4>\r\nVOCÊ DEVE SER MAIOR DE DEZOITO (18) ANOS PARA ACESSAR ESTA PÁGINA. SE VOCÊ É MENOR DE DEZOITO ANOS DE IDADE, NÃO TEM PERMISSÃO PARA ACESSAR ESTA PÁGINA EM HIPÓTESE ALGUMA. DEVIDO À RESTRIÇÃO DE IDADE PARA TAL USO, NENHUMA INFORMAÇÃO OBTIDA POR ESTA PÁGINA SE ENQUADRA NA LEI DE PROTEÇÃO DA PRIVACIDADE ONLINE DE CRIANÇAS (COPPA) E NÃO É MONITORADA PARA TAL FIM. Para acessar esta página e alguns dos recursos que ela oferece, você pode ser requisitado a fornecer certos detalhes de registro ou outras informações. É uma condição de uso desta página que todas as informações fornecidas por você nesta página sejam corretas, atuais e completas. Caso nossa Empresa julgue que as informações fornecidas por você não são corretas, atuais e completas, temos o direito de recusar seu acesso a esta página ou qualquer um de seus recursos e encerrar ou suspender seu acesso à qualquer momento, sem aviso prévio.\r\n<h4><b>Restrições de uso</b></h4>\r\nVocê pode usar esta página para fins estritamente permitidos pela mesma. Você não pode usar esta página para qualquer outro fim, incluindo qualquer propósito comercial, sem o consentimento prévio por escrito por parte de nossa Empresa. Por exemplo, você não pode (e não pode autorizar qualquer outra parte a) (I) criar uma cooperatividade de marca, ou (II) reestruturar esta página, ou (III) fazer um link a esta página, sem o consentimento prévio por escrito por parte de um representante autorizado de nossa Empresa. Para os fins destes Termos de Uso, “cooperatividade de marca” significa exibir um nome, logo, marca registrada, ou outros meios de atribuição ou identificação de qualquer parte de forma que seja possivelmente provável que outro usuário tenha a impressão de que tal outra parte tem o direito de exibir, publicar ou distribuir esta página ou conteúdo acessível dentro desta página. Você concorda em cooperar com nossa Empresa para que qualquer cooperatividade de marca, reestruturação ou vinculação seja imediatamente interrompida.\r\n<h4><b>Informações registradas</b></h4>\r\nO material e conteúdo (a seguir designado como “Conteúdo”) acessível a partir desta página, e qualquer outra página da Rede Mundial de Computadores de propriedade, operado, licenciado ou controlado por nossa Empresa é de propriedade de nossa Empresa ou da parte que forneceu o Conteúdo à nossa Empresa, e nossa Empresa ou a outra parte que forneceu o Conteúdo à nossa Empresa detém todos os direitos, títulos e interesses no Conteúdo. Da mesma forma, o Conteúdo não pode ser copiado, distribuído, republicado, carregado, postado ou transmitido de qualquer forma sem o consentimento prévio por escrito por parte de nossa Empresa, ou a menos que autorizado por escrito em alguma parte de nossa página, exceto no caso de você imprimir uma cópia do Conteúdo unicamente para seu uso pessoal. Neste caso, você não pode remover ou alterar, ou causar uma remoção ou alteração de qualquer direito autoral, marca registrada, nome comercial, marca de serviço, ou qualquer outro aviso de propriedade ou legenda que apareça em qualquer parte do Conteúdo. A modificação ou uso do Conteúdo, exceto explicitamente informado por esta Condição de Uso, viola os direitos de propriedade intelectual de nossa Empresa. Nem propriedade nem direitos de propriedade intelectual são transferidos a você ao acessar esta página.\r\n<h4><b>Hyperlinks</b></h4>\r\nEsta página pode ser vinculada a outras páginas que não são mantidas por, ou relacionadas à nossa Empresa. Os hyperlinks a outras páginas são fornecidos como um serviço aos usuários e não são patrocinados por, ou afiliados a esta página ou nossa Empresa. Nossa Empresa não revisou qualquer ou todas estas páginas e não se responsabiliza pelo conteúdo de tais páginas. O usuário se responsabiliza pelo risco ao acesso destes hyperlinks, e nossa Empresa não representa ou dá qualquer garantia sobre o conteúdo, integridade ou fidelidade de tais hyperlinks ou páginas vinculadas a esta página. Ainda, a inclusão de qualquer hyperlink a uma página de terceiros não implica endosso desta página por parte de nossa Empresa.\r\n<h4><b>Submissões</b></h4>\r\nVocê, por meio desta, concede à nossa Empresa o direito não exclusivo, livre de royalty, perpétuo, irrevogável, universal, e a licença para usar, reproduzir, modificar, adaptar, publicar, traduzir, criar trabalhos derivados de, distribuir, executar e exibir todo o conteúdo, observações, sugestões, ideias, gráficos ou outras informações comunicadas à nossa Empresa através desta página (juntas, daqui por diante conhecida como “Submissão”), e incorporar qualquer Submissão em outros trabalhos em qualquer forma, mídia, ou tecnologia conhecida ou por ser ainda desenvolvida. Nossa Empresa não precisará tratar qualquer Submissão como sendo confidencial, e poderá utilizar qualquer Submissão em seu negócio (incluindo e sem limitação, para produtos ou propaganda) sem incorrer em qualquer responsabilidade por royalties ou qualquer outra consideração de qualquer tipo e não incorrerá em qualquer responsabilidade como resultado de quaisquer semelhanças que possam aparecer em operações futuras da Empresa. Nossa Empresa tratará qualquer informação pessoal que você envia através deste site de acordo com sua <a href=\"https://hempmedspx.com/privacy-policy/\">Política de Privacidade</a>conforme estabelecido neste site.\r\n<h4><b>Isenção de Responsabilidade</b></h4>\r\nVocê entende que nossa Empresa não pode, e não garante que os arquivos disponíveis para download na Internet estão livres de vírus, worms, cavalos de Tróia ou outro código que possa manifestar propriedades contaminantes ou destrutivas. Você é responsável por implementar procedimentos e pontos de verificação suficientes para satisfazer suas necessidades específicas de precisão de entrada e saída de dados e por manter um meio externo a este site para a recuperação de dados perdidos. A nossa empresa não assume qualquer responsabilidade ou risco decorrente de seu uso da Internet. O conteúdo não está necessariamente concluído e atualizado, e não deve ser usado para substituir quaisquer relatórios por escrito, declarações ou avisos fornecidos pela empresa.\r\n\r\nOs investidores, mutuários e outras pessoas devem usar o Conteúdo da mesma maneira que qualquer outro meio educacional e não devem confiar no Conteúdo com exclusão de seu próprio julgamento profissional. As informações obtidas através deste site não são definitivas e não cobrem todas as questões, tópicos ou fatos que podem ser relevantes a seus objetivos. VOCÊ ASSUME TODOS OS RISCOS RELACIONADOS À UTILIZAÇÃO DESTE SITE. O Conteúdo é fornecido \"tal como está\" e sem garantias de qualquer tipo, expressas ou implícitas. Nossa Empresa se isenta de todas as garantias, incluindo quaisquer garantias implícitas de comercialização, adequação a um propósito específico, TÍTULO, OU NÃO-VIOLAÇÃO. Nossa Empresa não garante que as funções OU CONTEÚDOS contidos neste site serão ininterruptos ou sem erros, que os defeitos serão corrigidos, ou que este site ou o servidor que o disponibiliza estão livres de vírus ou outros componentes nocivos. Nossa Empresa não garante nem faz qualquer representação com respeito ao uso, ou ao resultado do uso, do conteúdo em termos de exatidão, confiabilidade ou de outra forma. O conteúdo pode incluir imprecisões técnicas ou erros tipográficos, e a Empresa pode fazer alterações ou melhorias a qualquer momento. Você, e não nossa Empresa, assume o custo total de todas as manutenções, reparos ou correções necessárias, EM CASO DE QUALQUER PERDA OU DANO DECORRENTE DO USO DESTE SITE OU DO SEU CONTEÚDO. Nossa EMPRESA NÃO OFERECE QUALQUER GARANTIA DE QUE O SEU USO DO CONTEÚDO NÃO INFRINGE OS DIREITOS DE OUTROS E NÃO ASSUME RESPONSABILIDADE POR ERROS OU OMISSÕES NESSE CONTEÚDO. Toda a informação contida neste site, seja de natureza histórica ou prospectiva, fala apenas a partir da data em que as informações são publicadas neste site, ea Empresa não assume nenhuma obrigação de atualizar essas informações depois de publicadas ou de remover tais informações. Informações deste site se ele não estiver, ou não estiver mais, exato ou completo. Toda a informação contida neste site, seja de natureza histórica ou prospectiva, fala apenas a partir da data em que as informações são publicadas neste site, e a Empresa não assume nenhuma obrigação de atualizar essas informações depois de publicadas ou de remover tais informações deste site se ele não estiver, ou não estiver mais, exato ou completo.\r\n<h4><b>Limitação de Responsabilidade</b></h4>\r\nESTA EMPRESA, SUAS SUBSIDIÁRIAS, AFILIADOS, LICENCIADORES, FORNECEDORES DE SERVIÇOS, FORNECEDORES DE CONTEÚDOS, FUNCIONÁRIOS, AGENTES, OFICIAIS E DIRETORES NÃO SERÃO RESPONSÁVEIS POR QUAISQUER DANOS INCIDENTAIS, DIRETOS, INDIRETOS, PUNITIVOS, REAIS, CONSEQÜENCIAIS, ESPECIAIS, EXEMPLARES OU OUTROS DANOS, INCLUINDO PERDA DE RECEITAS OU RENDA, DOR E SOFRIMENTO, PROBLEMA EMOCIONAL OU DANOS SIMILARES, MESMO QUE A EMPRESA TENHA SIDO AVISADA DA POSSIBILIDADE DE TAIS DANOS. EM NENHUM CASO A RESPONSABILIDADE COLETIVA DA EMPRESA E SUAS SUBSIDIÁRIAS, AFILIADAS, LICENCIADORES, FORNECEDORES DE SERVIÇOS, FORNECEDORES DE CONTEÚDOS, EMPREGADOS, AGENTES, OFICIAIS E DIRETORES, A QUALQUER PARTE (INDEPENDENTEMENTE DA FORMA DE AÇÃO, SEJA POR CONTRATO, AÇÃO, OU DE QUALQUER OUTRA FORMA) EXCEDER MAIS QUE US$100 OU O MONTANTE QUE VOCÊ PAGOU À EMPRESA PARA O CONTEÚDO RELACIONADO, PRODUTO OU SERVIÇO APLICÁVEL À RESPONSABILIDADE EM QUESTÃO.\r\n<h4><b>Indenização</b></h4>\r\nVocê indenizará e manterá a Empresa inocente, suas subsidiárias, afiliadas, licenciadores, provedores de conteúdo, prestadores de serviços, funcionários, agentes, oficiais, diretores e contratados (doravante denominados \"Partes Indenizadas\") de qualquer violação destes Termos de Uso por você, incluindo qualquer uso de Conteúdo que não seja expressamente autorizado nestes Termos de Uso. Você concorda que as Partes Indenizadas não terão nenhuma responsabilidade relacionada a tal violação ou uso não autorizado, e você concorda em indenizar todas e quaisquer perdas, danos, julgamentos, prêmios, custos, despesas e honorários advocatícios resultantes das Partes Indenizadas relacionadas. Você também indenizará e manterá as Partes Indenizadas inocentes de e contra quaisquer reivindicações feitas por terceiros decorrentes do uso das informações acessadas neste site.\r\n<h4><b>Marcas registradas</b></h4>\r\nAs marcas registradas, marcas de serviço e logotipos que aparecem neste site são propriedade da Empresa ou da parte que forneceu as marcas registradas, marcas de serviço e logotipos da Empresa. A Empresa e qualquer parte que forneceu marcas registradas, marcas de serviço e logotipos à Empresa mantém todos os direitos relacionados a qualquer uma das respectivas marcas registradas, marcas de serviço e logotipos que aparecem neste site.\r\n<h4><b>Informações fornecidas por você</b></h4>\r\nVocê não pode publicar, enviar, submeter, publicar ou transmitir, em conexão a este site, qualquer material que:\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>você não tem o direito de postar, incluindo material registrado de terceiros;</li>\r\n 	<li>promove atividades ilegais ou discute a intenção de cometer um ato ilegal;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>seja vulgar, obceno, pornográfico ou indecente;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>não pertence diretamente a este site;</li>\r\n 	<li>ameaça ou abusa de outros, calunia, difama, invade a privacidade, persegue, é obsceno, pornográfico, racista, abusivo, assediante, ameaçador ou ofensivo;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>procura explorar ou prejudicar crianças expondo-as a conteúdo impróprio, solicitando detalhes pessoais identificáveis ou de outra forma;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>infringe qualquer propriedade intelectual ou outro direito de qualquer entidade ou pessoa, incluindo violação de direitos autorais ou marcas registradas ou seus direitos de publicidade;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>viola quaisquer leis ou possa ser considerado em violação de qualquer lei;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>personifica ou desvirtua sua conexão com qualquer outra entidade ou pessoa ou manipula cabeçalhos ou identificadores para disfarçar a origem do conteúdo;</li>\r\n 	<li>anuncia qualquer empreendimento comercial (por exemplo, oferecendo produtos ou serviços) ou de outra forma envolve qualquer atividade comercial (por exemplo, conduzir sorteios ou concursos, exibição de banners de patrocínio e/ou solicitação de bens ou serviços), exceto quando especificamente autorizado neste site;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>solicita fundos, anunciantes ou patrocinadores;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>inclui programas que contêm vírus, worms e/ou cavalos de Tróia ou qualquer outro código de computador, arquivos ou programas destinados a interromper, destruir ou limitar a funcionalidade de qualquer software de computador ou hardware ou telecomunicações;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>interrompe o fluxo normal de diálogo, faz com que uma tela role mais rápido do que outros usuários sejam capazes de digitar, ou agir de outra forma que afete a capacidade de outras pessoas em participar de atividades em tempo real através deste site;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>inclui arquivos em formato MP3;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>equivale a uma “pirâmide” ou a um esquema semelhante;</li>\r\n 	<li>desobedeça qualquer política ou regulamentação estabelecida de tempos em tempos com relação ao uso deste site ou de quaisquer redes conectadas a este site; ou</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>contém hiperlinks para outros sites que contêm conteúdo que se enquadra dentro das descrições estabelecidas acima.</li>\r\n</ul>\r\n</li>\r\n</ul>\r\nEmbora não seja obrigado a fazê-lo, nossa Empresa se reserva o direito de monitorar o uso deste site para determinar o cumprimento destes Termos de Uso, bem como o direito de remover ou recusar qualquer informação por qualquer motivo. Não obstante estes direitos, você permanece unicamente responsável pelo conteúdo de suas submissões. Você reconhece e concorda que nem a Empresa nem qualquer terceiro que forneça Conteúdo à Empresa assumirá ou terá qualquer responsabilidade por qualquer ação ou inação da Empresa ou de terceiros em relação a qualquer submissão.\r\n<h4><b>Segurança</b></h4>\r\nAs senhas usadas neste site são para uso individual apenas. Você será responsável pela segurança de sua senha (se houver). A Empresa terá o direito de monitorar sua senha e, a seu critério, exigir que você a altere. Se você usar uma senha que a Empresa considere insegura, a Empresa terá o direito de exigir que a senha seja alterada e/ou encerrar sua conta. Você está proibido de usar quaisquer serviços ou instalações fornecidas em conexão a este site para comprometer a segurança ou manipular os recursos do sistema e/ou contas. O uso ou distribuição de ferramentas projetadas para comprometer a segurança (por exemplo, programas de adivinhação de senhas, ferramentas de ruptura de sistemas ou ferramentas de sondagem de rede) é estritamente proibido. Se você se envolver em qualquer violação da segurança do sistema, a Empresa se reserva o direito de divulgar seus detalhes aos administradores do sistema em outros sites para ajudá-los a resolver problemas de segurança. A Empresa reserva-se o direito de investigar violações suspeitas destes Termos de Uso. A Empresa reserva-se o direito de cooperar plenamente com quaisquer autoridades policiais ou ordens judiciais solicitando ou levando a Empresa a divulgar a identidade de qualquer pessoa que esteja enviando mensagens de e-mail, ou publicando ou disponibilizando qualquer material que se acredite violar estes Termos de Uso. AO ACEITAR ESTE ACORDO, VOCÊ RENUNCIA E INOCENTA A EMPRESA DE QUAISQUER REIVINDICAÇÕES RESULTANTES DE QUALQUER AÇÃO TOMADA PELA EMPRESA DURANTE OU COMO RESULTADO DE SUAS INVESTIGAÇÕES E/OU DE QUAISQUER AÇÕES TOMADAS COMO CONSEQUÊNCIA DE INVESTIGAÇÃO PELA EMPRESA OU AUTORIDADES RESPONSÁVEIS PELA APLICAÇÃO DA LEI.\r\n<h4><b>Diversos</b></h4>\r\nEstes Termos de Uso serão regidos e interpretados de acordo com as leis da Califórnia, Estados Unidos da América, não obstante quaisquer princípios de conflitos de leis. Você concorda especificamente com a jurisdição pessoal na Califórnia em relação a qualquer disputa entre você e a Empresa decorrente destes Termos de Uso ou referentes ao assunto aqui tratado. As partes destes Termos de Uso concordam que o foro exclusivo para qualquer disputa entre as partes decorrentes destes Termos de Uso ou relativos ao assunto destes Termos de Uso será nos tribunais estaduais e federais na Califórnia. Se qualquer parte destes Termos de Uso for ilegal, nula ou inaplicável, essa parte será julgada à parte e não afetará a validade e exequibilidade de quaisquer provisões restantes. Estes Termos de Uso constituem o acordo integral entre as partes relativo a este assunto. Não obstante o acima exposto, quaisquer termos e condições adicionais neste site irão reger os itens a que pertencem. A Empresa poderá rever estes Termos de Uso a qualquer momento, atualizando esta publicação.","Termos de Uso","","publish","closed","closed","","termos-de-uso","","","2018-07-11 03:15:16","2018-07-11 06:15:16","","0","http://localhost/cbdmed/?page_id=49","0","page","","0");
INSERT INTO wp_posts VALUES("50","1","2018-07-11 03:15:16","2018-07-11 06:15:16","MPORTANTE! ESTAS CONDIÇÕES DE SERVIÇO (CdS) GOVERNAM O USO DESTA PÁGINA, A QUAL É FORNECIDA POR NOSSA EMPRESA. AO ACESSAR ESTA PÁGINA VOCÊ CONFIRMA QUE CONHECE E ACEITA ESTAS CONDIÇÕES, AS QUAIS ESTÃO SUJEITAS A ALTERAÇÕES A QUALQUER MOMENTO POR PARTE DE NOSSA EMPRESA. A UTILIZAÇÃO DESTA PÁGINA APÓS A IMPLEMENTAÇÃO DE TAIS ALTERAÇÕES CONFIGURA SEU RECONHECIMENTO E ACEITAÇÃO DAS MESMAS. CONSULTE ESTES TERMOS DE USO REGULARMENTE\r\n<h4><b>Acesso a esta página</b></h4>\r\nVOCÊ DEVE SER MAIOR DE DEZOITO (18) ANOS PARA ACESSAR ESTA PÁGINA. SE VOCÊ É MENOR DE DEZOITO ANOS DE IDADE, NÃO TEM PERMISSÃO PARA ACESSAR ESTA PÁGINA EM HIPÓTESE ALGUMA. DEVIDO À RESTRIÇÃO DE IDADE PARA TAL USO, NENHUMA INFORMAÇÃO OBTIDA POR ESTA PÁGINA SE ENQUADRA NA LEI DE PROTEÇÃO DA PRIVACIDADE ONLINE DE CRIANÇAS (COPPA) E NÃO É MONITORADA PARA TAL FIM. Para acessar esta página e alguns dos recursos que ela oferece, você pode ser requisitado a fornecer certos detalhes de registro ou outras informações. É uma condição de uso desta página que todas as informações fornecidas por você nesta página sejam corretas, atuais e completas. Caso nossa Empresa julgue que as informações fornecidas por você não são corretas, atuais e completas, temos o direito de recusar seu acesso a esta página ou qualquer um de seus recursos e encerrar ou suspender seu acesso à qualquer momento, sem aviso prévio.\r\n<h4><b>Restrições de uso</b></h4>\r\nVocê pode usar esta página para fins estritamente permitidos pela mesma. Você não pode usar esta página para qualquer outro fim, incluindo qualquer propósito comercial, sem o consentimento prévio por escrito por parte de nossa Empresa. Por exemplo, você não pode (e não pode autorizar qualquer outra parte a) (I) criar uma cooperatividade de marca, ou (II) reestruturar esta página, ou (III) fazer um link a esta página, sem o consentimento prévio por escrito por parte de um representante autorizado de nossa Empresa. Para os fins destes Termos de Uso, “cooperatividade de marca” significa exibir um nome, logo, marca registrada, ou outros meios de atribuição ou identificação de qualquer parte de forma que seja possivelmente provável que outro usuário tenha a impressão de que tal outra parte tem o direito de exibir, publicar ou distribuir esta página ou conteúdo acessível dentro desta página. Você concorda em cooperar com nossa Empresa para que qualquer cooperatividade de marca, reestruturação ou vinculação seja imediatamente interrompida.\r\n<h4><b>Informações registradas</b></h4>\r\nO material e conteúdo (a seguir designado como “Conteúdo”) acessível a partir desta página, e qualquer outra página da Rede Mundial de Computadores de propriedade, operado, licenciado ou controlado por nossa Empresa é de propriedade de nossa Empresa ou da parte que forneceu o Conteúdo à nossa Empresa, e nossa Empresa ou a outra parte que forneceu o Conteúdo à nossa Empresa detém todos os direitos, títulos e interesses no Conteúdo. Da mesma forma, o Conteúdo não pode ser copiado, distribuído, republicado, carregado, postado ou transmitido de qualquer forma sem o consentimento prévio por escrito por parte de nossa Empresa, ou a menos que autorizado por escrito em alguma parte de nossa página, exceto no caso de você imprimir uma cópia do Conteúdo unicamente para seu uso pessoal. Neste caso, você não pode remover ou alterar, ou causar uma remoção ou alteração de qualquer direito autoral, marca registrada, nome comercial, marca de serviço, ou qualquer outro aviso de propriedade ou legenda que apareça em qualquer parte do Conteúdo. A modificação ou uso do Conteúdo, exceto explicitamente informado por esta Condição de Uso, viola os direitos de propriedade intelectual de nossa Empresa. Nem propriedade nem direitos de propriedade intelectual são transferidos a você ao acessar esta página.\r\n<h4><b>Hyperlinks</b></h4>\r\nEsta página pode ser vinculada a outras páginas que não são mantidas por, ou relacionadas à nossa Empresa. Os hyperlinks a outras páginas são fornecidos como um serviço aos usuários e não são patrocinados por, ou afiliados a esta página ou nossa Empresa. Nossa Empresa não revisou qualquer ou todas estas páginas e não se responsabiliza pelo conteúdo de tais páginas. O usuário se responsabiliza pelo risco ao acesso destes hyperlinks, e nossa Empresa não representa ou dá qualquer garantia sobre o conteúdo, integridade ou fidelidade de tais hyperlinks ou páginas vinculadas a esta página. Ainda, a inclusão de qualquer hyperlink a uma página de terceiros não implica endosso desta página por parte de nossa Empresa.\r\n<h4><b>Submissões</b></h4>\r\nVocê, por meio desta, concede à nossa Empresa o direito não exclusivo, livre de royalty, perpétuo, irrevogável, universal, e a licença para usar, reproduzir, modificar, adaptar, publicar, traduzir, criar trabalhos derivados de, distribuir, executar e exibir todo o conteúdo, observações, sugestões, ideias, gráficos ou outras informações comunicadas à nossa Empresa através desta página (juntas, daqui por diante conhecida como “Submissão”), e incorporar qualquer Submissão em outros trabalhos em qualquer forma, mídia, ou tecnologia conhecida ou por ser ainda desenvolvida. Nossa Empresa não precisará tratar qualquer Submissão como sendo confidencial, e poderá utilizar qualquer Submissão em seu negócio (incluindo e sem limitação, para produtos ou propaganda) sem incorrer em qualquer responsabilidade por royalties ou qualquer outra consideração de qualquer tipo e não incorrerá em qualquer responsabilidade como resultado de quaisquer semelhanças que possam aparecer em operações futuras da Empresa. Nossa Empresa tratará qualquer informação pessoal que você envia através deste site de acordo com sua <a href=\"https://hempmedspx.com/privacy-policy/\">Política de Privacidade</a>conforme estabelecido neste site.\r\n<h4><b>Isenção de Responsabilidade</b></h4>\r\nVocê entende que nossa Empresa não pode, e não garante que os arquivos disponíveis para download na Internet estão livres de vírus, worms, cavalos de Tróia ou outro código que possa manifestar propriedades contaminantes ou destrutivas. Você é responsável por implementar procedimentos e pontos de verificação suficientes para satisfazer suas necessidades específicas de precisão de entrada e saída de dados e por manter um meio externo a este site para a recuperação de dados perdidos. A nossa empresa não assume qualquer responsabilidade ou risco decorrente de seu uso da Internet. O conteúdo não está necessariamente concluído e atualizado, e não deve ser usado para substituir quaisquer relatórios por escrito, declarações ou avisos fornecidos pela empresa.\r\n\r\nOs investidores, mutuários e outras pessoas devem usar o Conteúdo da mesma maneira que qualquer outro meio educacional e não devem confiar no Conteúdo com exclusão de seu próprio julgamento profissional. As informações obtidas através deste site não são definitivas e não cobrem todas as questões, tópicos ou fatos que podem ser relevantes a seus objetivos. VOCÊ ASSUME TODOS OS RISCOS RELACIONADOS À UTILIZAÇÃO DESTE SITE. O Conteúdo é fornecido \"tal como está\" e sem garantias de qualquer tipo, expressas ou implícitas. Nossa Empresa se isenta de todas as garantias, incluindo quaisquer garantias implícitas de comercialização, adequação a um propósito específico, TÍTULO, OU NÃO-VIOLAÇÃO. Nossa Empresa não garante que as funções OU CONTEÚDOS contidos neste site serão ininterruptos ou sem erros, que os defeitos serão corrigidos, ou que este site ou o servidor que o disponibiliza estão livres de vírus ou outros componentes nocivos. Nossa Empresa não garante nem faz qualquer representação com respeito ao uso, ou ao resultado do uso, do conteúdo em termos de exatidão, confiabilidade ou de outra forma. O conteúdo pode incluir imprecisões técnicas ou erros tipográficos, e a Empresa pode fazer alterações ou melhorias a qualquer momento. Você, e não nossa Empresa, assume o custo total de todas as manutenções, reparos ou correções necessárias, EM CASO DE QUALQUER PERDA OU DANO DECORRENTE DO USO DESTE SITE OU DO SEU CONTEÚDO. Nossa EMPRESA NÃO OFERECE QUALQUER GARANTIA DE QUE O SEU USO DO CONTEÚDO NÃO INFRINGE OS DIREITOS DE OUTROS E NÃO ASSUME RESPONSABILIDADE POR ERROS OU OMISSÕES NESSE CONTEÚDO. Toda a informação contida neste site, seja de natureza histórica ou prospectiva, fala apenas a partir da data em que as informações são publicadas neste site, ea Empresa não assume nenhuma obrigação de atualizar essas informações depois de publicadas ou de remover tais informações. Informações deste site se ele não estiver, ou não estiver mais, exato ou completo. Toda a informação contida neste site, seja de natureza histórica ou prospectiva, fala apenas a partir da data em que as informações são publicadas neste site, e a Empresa não assume nenhuma obrigação de atualizar essas informações depois de publicadas ou de remover tais informações deste site se ele não estiver, ou não estiver mais, exato ou completo.\r\n<h4><b>Limitação de Responsabilidade</b></h4>\r\nESTA EMPRESA, SUAS SUBSIDIÁRIAS, AFILIADOS, LICENCIADORES, FORNECEDORES DE SERVIÇOS, FORNECEDORES DE CONTEÚDOS, FUNCIONÁRIOS, AGENTES, OFICIAIS E DIRETORES NÃO SERÃO RESPONSÁVEIS POR QUAISQUER DANOS INCIDENTAIS, DIRETOS, INDIRETOS, PUNITIVOS, REAIS, CONSEQÜENCIAIS, ESPECIAIS, EXEMPLARES OU OUTROS DANOS, INCLUINDO PERDA DE RECEITAS OU RENDA, DOR E SOFRIMENTO, PROBLEMA EMOCIONAL OU DANOS SIMILARES, MESMO QUE A EMPRESA TENHA SIDO AVISADA DA POSSIBILIDADE DE TAIS DANOS. EM NENHUM CASO A RESPONSABILIDADE COLETIVA DA EMPRESA E SUAS SUBSIDIÁRIAS, AFILIADAS, LICENCIADORES, FORNECEDORES DE SERVIÇOS, FORNECEDORES DE CONTEÚDOS, EMPREGADOS, AGENTES, OFICIAIS E DIRETORES, A QUALQUER PARTE (INDEPENDENTEMENTE DA FORMA DE AÇÃO, SEJA POR CONTRATO, AÇÃO, OU DE QUALQUER OUTRA FORMA) EXCEDER MAIS QUE US$100 OU O MONTANTE QUE VOCÊ PAGOU À EMPRESA PARA O CONTEÚDO RELACIONADO, PRODUTO OU SERVIÇO APLICÁVEL À RESPONSABILIDADE EM QUESTÃO.\r\n<h4><b>Indenização</b></h4>\r\nVocê indenizará e manterá a Empresa inocente, suas subsidiárias, afiliadas, licenciadores, provedores de conteúdo, prestadores de serviços, funcionários, agentes, oficiais, diretores e contratados (doravante denominados \"Partes Indenizadas\") de qualquer violação destes Termos de Uso por você, incluindo qualquer uso de Conteúdo que não seja expressamente autorizado nestes Termos de Uso. Você concorda que as Partes Indenizadas não terão nenhuma responsabilidade relacionada a tal violação ou uso não autorizado, e você concorda em indenizar todas e quaisquer perdas, danos, julgamentos, prêmios, custos, despesas e honorários advocatícios resultantes das Partes Indenizadas relacionadas. Você também indenizará e manterá as Partes Indenizadas inocentes de e contra quaisquer reivindicações feitas por terceiros decorrentes do uso das informações acessadas neste site.\r\n<h4><b>Marcas registradas</b></h4>\r\nAs marcas registradas, marcas de serviço e logotipos que aparecem neste site são propriedade da Empresa ou da parte que forneceu as marcas registradas, marcas de serviço e logotipos da Empresa. A Empresa e qualquer parte que forneceu marcas registradas, marcas de serviço e logotipos à Empresa mantém todos os direitos relacionados a qualquer uma das respectivas marcas registradas, marcas de serviço e logotipos que aparecem neste site.\r\n<h4><b>Informações fornecidas por você</b></h4>\r\nVocê não pode publicar, enviar, submeter, publicar ou transmitir, em conexão a este site, qualquer material que:\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>você não tem o direito de postar, incluindo material registrado de terceiros;</li>\r\n 	<li>promove atividades ilegais ou discute a intenção de cometer um ato ilegal;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>seja vulgar, obceno, pornográfico ou indecente;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>não pertence diretamente a este site;</li>\r\n 	<li>ameaça ou abusa de outros, calunia, difama, invade a privacidade, persegue, é obsceno, pornográfico, racista, abusivo, assediante, ameaçador ou ofensivo;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>procura explorar ou prejudicar crianças expondo-as a conteúdo impróprio, solicitando detalhes pessoais identificáveis ou de outra forma;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>infringe qualquer propriedade intelectual ou outro direito de qualquer entidade ou pessoa, incluindo violação de direitos autorais ou marcas registradas ou seus direitos de publicidade;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>viola quaisquer leis ou possa ser considerado em violação de qualquer lei;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>personifica ou desvirtua sua conexão com qualquer outra entidade ou pessoa ou manipula cabeçalhos ou identificadores para disfarçar a origem do conteúdo;</li>\r\n 	<li>anuncia qualquer empreendimento comercial (por exemplo, oferecendo produtos ou serviços) ou de outra forma envolve qualquer atividade comercial (por exemplo, conduzir sorteios ou concursos, exibição de banners de patrocínio e/ou solicitação de bens ou serviços), exceto quando especificamente autorizado neste site;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>solicita fundos, anunciantes ou patrocinadores;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>inclui programas que contêm vírus, worms e/ou cavalos de Tróia ou qualquer outro código de computador, arquivos ou programas destinados a interromper, destruir ou limitar a funcionalidade de qualquer software de computador ou hardware ou telecomunicações;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>interrompe o fluxo normal de diálogo, faz com que uma tela role mais rápido do que outros usuários sejam capazes de digitar, ou agir de outra forma que afete a capacidade de outras pessoas em participar de atividades em tempo real através deste site;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>inclui arquivos em formato MP3;</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>equivale a uma “pirâmide” ou a um esquema semelhante;</li>\r\n 	<li>desobedeça qualquer política ou regulamentação estabelecida de tempos em tempos com relação ao uso deste site ou de quaisquer redes conectadas a este site; ou</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<ul>\r\n 	<li style=\"list-style-type: none;\">\r\n<ul>\r\n 	<li>contém hiperlinks para outros sites que contêm conteúdo que se enquadra dentro das descrições estabelecidas acima.</li>\r\n</ul>\r\n</li>\r\n</ul>\r\nEmbora não seja obrigado a fazê-lo, nossa Empresa se reserva o direito de monitorar o uso deste site para determinar o cumprimento destes Termos de Uso, bem como o direito de remover ou recusar qualquer informação por qualquer motivo. Não obstante estes direitos, você permanece unicamente responsável pelo conteúdo de suas submissões. Você reconhece e concorda que nem a Empresa nem qualquer terceiro que forneça Conteúdo à Empresa assumirá ou terá qualquer responsabilidade por qualquer ação ou inação da Empresa ou de terceiros em relação a qualquer submissão.\r\n<h4><b>Segurança</b></h4>\r\nAs senhas usadas neste site são para uso individual apenas. Você será responsável pela segurança de sua senha (se houver). A Empresa terá o direito de monitorar sua senha e, a seu critério, exigir que você a altere. Se você usar uma senha que a Empresa considere insegura, a Empresa terá o direito de exigir que a senha seja alterada e/ou encerrar sua conta. Você está proibido de usar quaisquer serviços ou instalações fornecidas em conexão a este site para comprometer a segurança ou manipular os recursos do sistema e/ou contas. O uso ou distribuição de ferramentas projetadas para comprometer a segurança (por exemplo, programas de adivinhação de senhas, ferramentas de ruptura de sistemas ou ferramentas de sondagem de rede) é estritamente proibido. Se você se envolver em qualquer violação da segurança do sistema, a Empresa se reserva o direito de divulgar seus detalhes aos administradores do sistema em outros sites para ajudá-los a resolver problemas de segurança. A Empresa reserva-se o direito de investigar violações suspeitas destes Termos de Uso. A Empresa reserva-se o direito de cooperar plenamente com quaisquer autoridades policiais ou ordens judiciais solicitando ou levando a Empresa a divulgar a identidade de qualquer pessoa que esteja enviando mensagens de e-mail, ou publicando ou disponibilizando qualquer material que se acredite violar estes Termos de Uso. AO ACEITAR ESTE ACORDO, VOCÊ RENUNCIA E INOCENTA A EMPRESA DE QUAISQUER REIVINDICAÇÕES RESULTANTES DE QUALQUER AÇÃO TOMADA PELA EMPRESA DURANTE OU COMO RESULTADO DE SUAS INVESTIGAÇÕES E/OU DE QUAISQUER AÇÕES TOMADAS COMO CONSEQUÊNCIA DE INVESTIGAÇÃO PELA EMPRESA OU AUTORIDADES RESPONSÁVEIS PELA APLICAÇÃO DA LEI.\r\n<h4><b>Diversos</b></h4>\r\nEstes Termos de Uso serão regidos e interpretados de acordo com as leis da Califórnia, Estados Unidos da América, não obstante quaisquer princípios de conflitos de leis. Você concorda especificamente com a jurisdição pessoal na Califórnia em relação a qualquer disputa entre você e a Empresa decorrente destes Termos de Uso ou referentes ao assunto aqui tratado. As partes destes Termos de Uso concordam que o foro exclusivo para qualquer disputa entre as partes decorrentes destes Termos de Uso ou relativos ao assunto destes Termos de Uso será nos tribunais estaduais e federais na Califórnia. Se qualquer parte destes Termos de Uso for ilegal, nula ou inaplicável, essa parte será julgada à parte e não afetará a validade e exequibilidade de quaisquer provisões restantes. Estes Termos de Uso constituem o acordo integral entre as partes relativo a este assunto. Não obstante o acima exposto, quaisquer termos e condições adicionais neste site irão reger os itens a que pertencem. A Empresa poderá rever estes Termos de Uso a qualquer momento, atualizando esta publicação.","Termos de Uso","","inherit","closed","closed","","49-revision-v1","","","2018-07-11 03:15:16","2018-07-11 06:15:16","","49","http://localhost/cbdmed/?p=50","0","revision","","0");
INSERT INTO wp_posts VALUES("51","1","2018-07-11 03:17:19","2018-07-11 06:17:19","<strong>Política de Privacidade</strong>\r\n\r\nSua privacidade é muito importante para nós. Queremos que sua experiência na Internet seja tão agradável e gratificante quanto possível e queremos que você use a vasta gama de informações, ferramentas e oportunidades da Internet com total confiança.\r\n\r\nCriamos esta Política de Privacidade para demonstrar o nosso compromisso firme com a privacidade e a segurança. Esta Política de Privacidade descreve como nossa empresa coleta informações de todos os usuários finais de nossos serviços de Internet (os \"Serviços\") - aqueles que acessam alguns de nossos Serviços, mas não possuem contas (\"Visitantes\"), bem como aqueles que podem comprar Produtos e/ou pagar uma taxa de serviço mensal para se inscrever no Serviço (\"Membros\") - o que fazemos com as informações que coletamos e as escolhas que os Visitantes e Membros têm sobre a coleta e uso dessas informações. Leia atentamente esta Política de Privacidade.\r\n\r\n<strong>Informações pessoais que nossa empresa cobra e como ela é usada</strong>\r\n\r\n<strong>Introdução:</strong>\r\n\r\nNossa empresa coleta informações de maneiras diferentes, desde Visitantes e Membros que acessam as diversas partes de nossos Serviços e a rede de páginas da Web acessíveis através do nosso Serviço. Usamos essas informações principalmente para fornecer uma experiência personalizada à medida que você usa nossos Produtos e Serviços e, em geral, não compartilhamos essas informações com terceiros. No entanto, podemos divulgar informações pessoais coletadas se recebemos sua permissão com antecedência ou em circunstâncias muito especiais, como quando acreditamos que essa divulgação é exigida por lei ou outros casos especiais descritos abaixo.\r\n\r\n<strong>Registro:</strong>\r\n\r\nOs membros podem ser solicitados a fornecer certas informações pessoais quando se inscreverem para nossos Produtos ou Serviços, incluindo nome, endereço, número de telefone, informações de cobrança (como um número de cartão de crédito) e o tipo de computador pessoal usado para acessar os Serviços. As informações pessoais coletadas dos Membros durante o processo de registro são usadas para administrar a conta de cada Membro (por exemplo, para fins de cobrança). Esta informação não é compartilhada com terceiros, exceto se expressamente mencionado em contrário ou em circunstâncias especiais.\r\n\r\nNo entanto, nos casos em que nossa empresa e um parceiro promovam em conjunto nossos Serviços, podemos fornecer ao membro certas informações pessoais, como o nome, endereço e nome de usuário das pessoas que se inscreveram nos Serviços como resultado da promoção conjunta, com o Propósito de permitir que nós e o parceiro avaliemos os resultados da promoção.\r\n\r\nNeste caso, informações pessoais não podem ser usadas pelo parceiro para qualquer outro propósito. Também podemos gerar perfis não identificáveis e agregados de informações pessoais que os Membros fornecem durante o registro (como o número total, mas não os nomes, dos Membros). Conforme explicado em mais detalhes abaixo, podemos usar essas informações agregadas e não identificáveis para vender anúncios que aparecem nos Serviços.\r\n\r\n<strong>Nossa Empresa, Parceiros e Patrocinadores:</strong>\r\n\r\nAlguns produtos e serviços podem ser oferecidos aos Visitantes e Membros em conjunto com um afiliado, um fornecedor contratado independente ou um parceiro não afiliado. Para fornecer visitantes e membros com alguns desses produtos e serviços, o membro pode precisar coletar e manter informações pessoais. Nestes casos, você será notificado antes de coletar ou transferir esses dados e pode decidir não usar esse serviço ou recurso específico.\r\n\r\nAlém disso, nossos parceiros podem ter anúncios ou páginas da web de co-marcas que são co-patrocinadas por um afiliado, um fornecedor contratado independente ou um parceiro não afiliado. Nossa empresa pode compartilhar informações não identificáveis e agregadas (exceto como descrito acima), mas não informações pessoais, com esses parceiros, a fim de gerenciar os produtos ou serviços co-marcados oferecidos.\r\n\r\n<strong>Anúncios online:</strong>\r\n\r\nNossa empresa pode mostrar nossos anúncios online. Nesses casos, compartilhamos informações agregadas e não identificáveis sobre nossos Visitantes e Membros coletados através do processo de registro, bem como através de pesquisas e promoções on-line com esses anunciantes.\r\n\r\nAlém disso, em alguns casos, usamos essas informações agregadas e não identificáveis para oferecer anúncios personalizados ou joint ventures. Por exemplo, um anunciante ou joint venture nos conta o público que eles querem alcançar e nos fornece um anúncio adaptado ao público. Com base nas informações agregadas e não identificáveis que coletamos, podemos mostrar ou enviar a propaganda para a audiência desejada. Nossa empresa não compartilha informações pessoais sobre seus visitantes ou membros com esses anunciantes ou joint ventures.\r\n\r\n<strong>Respostas às perguntas por e-mail:</strong>\r\n\r\nQuando os visitantes ou membros enviam consultas por e-mail para nossa empresa, o endereço de e-mail de retorno é usado para responder ao inquérito por e-mail que recebemos. Nossa empresa não usa o endereço de e-mail de retorno para qualquer outro propósito e não compartilha o endereço de e-mail de retorno com terceiros.\r\n\r\n<strong>Pesquisas voluntárias de clientes:</strong>\r\n\r\nPodemos realizar pesquisas periódicas de empresas e clientes individuais. Encorajamos nossos clientes a participar dessas pesquisas, pois nos fornecem informações importantes que nos ajudam a melhorar os tipos de produtos e serviços que oferecemos e como os fornecemos para você. Suas informações pessoais e suas respostas permanecerão estritamente confidenciais, mesmo que a pesquisa seja conduzida por terceiros. A participação em nossas pesquisas é voluntária.\r\n\r\nPodemos tomar as informações que recebemos dos indivíduos que respondem aos nossos inquéritos aos clientes e combiná-las com as respostas de outros clientes que possamos ter para criar respostas genéricas mais amplas às questões da pesquisa (como gênero, idade, residência, passatempos, educação, emprego, setor industrial ou outra informação demográfica). Então usamos a informação agregada para melhorar a qualidade de nossos serviços e desenvolver novos serviços e produtos. Esta informação agregada que não é pessoalmente identificável pode ser compartilhada com terceiros.\r\n\r\n<strong>Casos especiais:</strong>\r\n\r\nÉ política de nossa empresa não usar ou compartilhar informações pessoais sobre os Visitantes e Membros de maneiras não relacionadas às descritas acima, sem também lhe dar a oportunidade de optar por excluir ou proibir outros usos não relacionados.\r\n\r\nNo entanto, podemos divulgar informações pessoais sobre Visitantes ou Membros ou informações sobre o uso dos Serviços ou sites acessíveis através de nossos Serviços, por qualquer motivo se, a nosso exclusivo critério, acreditamos que seja razoável fazê-lo, incluindo: Agências; Agências de cobrança; Agências de banco de dados comerciais; Conformidade com a lei, ou para cumprir as leis, como a Lei de Privacidade de Comunicações Eletrônicas, a Lei de Privacidade de Crianças na Internet, os regulamentos ou os pedidos governamentais ou legais para tal informação; Divulgar informações que sejam necessárias para identificar, entrar em contato ou iniciar ações legais contra alguém que esteja violando nossa Política de Uso Aceitável ou Termos de Serviço ou outras políticas de usuários; Para operar os Serviços corretamente; Ou para proteger nossa empresa e nossos membros.\r\n\r\n<strong>\"Cookies\" e como nossa empresa os usa:</strong>\r\n\r\nUm \"cookie\" é um pequeno arquivo de dados que pode ser colocado em seu disco rígido quando você visita certas páginas da Web. Nossa empresa pode usar cookies para coletar, armazenar e, às vezes, rastrear informações com fins estatísticos para melhorar os produtos e serviços que oferecemos e gerenciar nossas redes de telecomunicações.\r\n\r\nSe você é Visitante ou Membro, podemos usar um cookie para salvar sua configuração e fornecer serviços personalizáveis e customizáveis. Esses cookies não permitem que terceiros acessem as informações do seu cliente. Além disso, tenha em mente que, se você visitar outros sites onde você é solicitado a fazer login ou que eles são personalizáveis, talvez seja necessário aceitar cookies.\r\n\r\nAnunciantes e parceiros também podem usar seus próprios cookies. Não controlamos o uso desses cookies e renunciamos expressamente à responsabilidade pelas informações coletadas através deles.\r\n\r\n<strong>Compromisso de nossa empresa com a privacidade de crianças:</strong>\r\n\r\nProteger a privacidade das crianças é especialmente importante para nós. É nossa política cumprir com a Lei de Proteção de Privacidade Online Infantil de 1998 e todas as demais leis aplicáveis. Portanto, restringimos nosso site para pessoas com idade superior a dezoito anos.\r\n\r\n<strong>As compras online:</strong>\r\n\r\nEm alguns sites, você pode comprar produtos e serviços ou se registrar para receber materiais, como uma newsletter, um catálogo ou um novo produto e atualizações de serviços. Em muitos casos, você pode ser solicitado a fornecer informações de contato, como seu nome, endereço, endereço de e-mail, número de telefone e informações de cartão de crédito / débito.\r\n\r\nSe você completar um pedido para outra pessoa, como um pedido de presente online enviado diretamente a um destinatário, você pode ser solicitado a fornecer informações sobre o destinatário, como o nome, o endereço e o número de telefone do destinatário. Nossa empresa não tem controle sobre o uso de terceiros para qualquer informação pessoal que você fornece ao fazer tal pedido. Tenha cuidado quando você faz isso.\r\n\r\nSe você solicitar serviços ou produtos diretamente de nossa empresa, usaremos as informações pessoais que você fornecerá apenas para processar esse pedido. Não compartilhamos essas informações com terceiros, exceto na medida necessária para concluir esse pedido.\r\n\r\nVocê deve ter dezoito (18) anos de idade ou mais para acessar este site. SE VOCÊ TEM MENOS DE DEZOITO ANOS DE IDADE, NÃO ESTÁ PERMITIDO A ACESSAR ESTE SITE DA WEB POR QUALQUER RAZÃO. DEVIDO ÀS RESTRIÇÕES DE IDADE PARA O USO DESTE SITE, NENHUMA INFORMAÇÃO OBTIDA POR ESTE SÍTIO DA WEB SE ENQUADRA NA LEI DE PRIVACIDADE ONLINE DE CRIANÇAS (COPA) E NÃO TEMOS CONTROLE SE O FAZEM.\r\n\r\n<strong>Fóruns públicos:</strong>\r\n\r\nLembre-se de que qualquer informação que você venha a divulgar em qualquer Diretório de Membros ou outras áreas públicas de nossos sites da Web ou Internet se tornam informações públicas. Você deve ter cuidado ao decidir revelar informações pessoais nessas áreas públicas.\r\n\r\n<strong>Compromisso da nossa empresa com a segurança dos dados:</strong>\r\n\r\nOs serviços e sites que patrocinamos têm medidas de segurança para proteger a perda, uso indevido e alteração das informações sob nosso controle. Embora façamos o nosso melhor para garantir a integridade e a segurança da nossa rede e sistemas, não podemos garantir que nossas medidas de segurança impeçam \"hackers\" de obter ilegalmente essa informação.\r\n\r\n<strong>Onde direcionar perguntas sobre nossa política de privacidade:</strong>\r\n\r\nSe você tiver alguma dúvida sobre esta Política de Privacidade ou as práticas descritas neste documento, você pode contatar-nos através das informações de contato fornecidas neste site.\r\n\r\n<strong>Revisões desta Política:</strong>\r\n\r\nNossa empresa se reserva o direito de revisar, alterar ou modificar esta política, nossos termos de serviço e nossas outras políticas e acordos a qualquer momento e de qualquer forma, atualizando esta publicação.","Política de Privacidade","","publish","closed","closed","","politica-de-privacidade","","","2018-07-11 03:17:19","2018-07-11 06:17:19","","0","http://localhost/cbdmed/?page_id=51","0","page","","0");
INSERT INTO wp_posts VALUES("52","1","2018-07-11 03:17:19","2018-07-11 06:17:19","<strong>Política de Privacidade</strong>\r\n\r\nSua privacidade é muito importante para nós. Queremos que sua experiência na Internet seja tão agradável e gratificante quanto possível e queremos que você use a vasta gama de informações, ferramentas e oportunidades da Internet com total confiança.\r\n\r\nCriamos esta Política de Privacidade para demonstrar o nosso compromisso firme com a privacidade e a segurança. Esta Política de Privacidade descreve como nossa empresa coleta informações de todos os usuários finais de nossos serviços de Internet (os \"Serviços\") - aqueles que acessam alguns de nossos Serviços, mas não possuem contas (\"Visitantes\"), bem como aqueles que podem comprar Produtos e/ou pagar uma taxa de serviço mensal para se inscrever no Serviço (\"Membros\") - o que fazemos com as informações que coletamos e as escolhas que os Visitantes e Membros têm sobre a coleta e uso dessas informações. Leia atentamente esta Política de Privacidade.\r\n\r\n<strong>Informações pessoais que nossa empresa cobra e como ela é usada</strong>\r\n\r\n<strong>Introdução:</strong>\r\n\r\nNossa empresa coleta informações de maneiras diferentes, desde Visitantes e Membros que acessam as diversas partes de nossos Serviços e a rede de páginas da Web acessíveis através do nosso Serviço. Usamos essas informações principalmente para fornecer uma experiência personalizada à medida que você usa nossos Produtos e Serviços e, em geral, não compartilhamos essas informações com terceiros. No entanto, podemos divulgar informações pessoais coletadas se recebemos sua permissão com antecedência ou em circunstâncias muito especiais, como quando acreditamos que essa divulgação é exigida por lei ou outros casos especiais descritos abaixo.\r\n\r\n<strong>Registro:</strong>\r\n\r\nOs membros podem ser solicitados a fornecer certas informações pessoais quando se inscreverem para nossos Produtos ou Serviços, incluindo nome, endereço, número de telefone, informações de cobrança (como um número de cartão de crédito) e o tipo de computador pessoal usado para acessar os Serviços. As informações pessoais coletadas dos Membros durante o processo de registro são usadas para administrar a conta de cada Membro (por exemplo, para fins de cobrança). Esta informação não é compartilhada com terceiros, exceto se expressamente mencionado em contrário ou em circunstâncias especiais.\r\n\r\nNo entanto, nos casos em que nossa empresa e um parceiro promovam em conjunto nossos Serviços, podemos fornecer ao membro certas informações pessoais, como o nome, endereço e nome de usuário das pessoas que se inscreveram nos Serviços como resultado da promoção conjunta, com o Propósito de permitir que nós e o parceiro avaliemos os resultados da promoção.\r\n\r\nNeste caso, informações pessoais não podem ser usadas pelo parceiro para qualquer outro propósito. Também podemos gerar perfis não identificáveis e agregados de informações pessoais que os Membros fornecem durante o registro (como o número total, mas não os nomes, dos Membros). Conforme explicado em mais detalhes abaixo, podemos usar essas informações agregadas e não identificáveis para vender anúncios que aparecem nos Serviços.\r\n\r\n<strong>Nossa Empresa, Parceiros e Patrocinadores:</strong>\r\n\r\nAlguns produtos e serviços podem ser oferecidos aos Visitantes e Membros em conjunto com um afiliado, um fornecedor contratado independente ou um parceiro não afiliado. Para fornecer visitantes e membros com alguns desses produtos e serviços, o membro pode precisar coletar e manter informações pessoais. Nestes casos, você será notificado antes de coletar ou transferir esses dados e pode decidir não usar esse serviço ou recurso específico.\r\n\r\nAlém disso, nossos parceiros podem ter anúncios ou páginas da web de co-marcas que são co-patrocinadas por um afiliado, um fornecedor contratado independente ou um parceiro não afiliado. Nossa empresa pode compartilhar informações não identificáveis e agregadas (exceto como descrito acima), mas não informações pessoais, com esses parceiros, a fim de gerenciar os produtos ou serviços co-marcados oferecidos.\r\n\r\n<strong>Anúncios online:</strong>\r\n\r\nNossa empresa pode mostrar nossos anúncios online. Nesses casos, compartilhamos informações agregadas e não identificáveis sobre nossos Visitantes e Membros coletados através do processo de registro, bem como através de pesquisas e promoções on-line com esses anunciantes.\r\n\r\nAlém disso, em alguns casos, usamos essas informações agregadas e não identificáveis para oferecer anúncios personalizados ou joint ventures. Por exemplo, um anunciante ou joint venture nos conta o público que eles querem alcançar e nos fornece um anúncio adaptado ao público. Com base nas informações agregadas e não identificáveis que coletamos, podemos mostrar ou enviar a propaganda para a audiência desejada. Nossa empresa não compartilha informações pessoais sobre seus visitantes ou membros com esses anunciantes ou joint ventures.\r\n\r\n<strong>Respostas às perguntas por e-mail:</strong>\r\n\r\nQuando os visitantes ou membros enviam consultas por e-mail para nossa empresa, o endereço de e-mail de retorno é usado para responder ao inquérito por e-mail que recebemos. Nossa empresa não usa o endereço de e-mail de retorno para qualquer outro propósito e não compartilha o endereço de e-mail de retorno com terceiros.\r\n\r\n<strong>Pesquisas voluntárias de clientes:</strong>\r\n\r\nPodemos realizar pesquisas periódicas de empresas e clientes individuais. Encorajamos nossos clientes a participar dessas pesquisas, pois nos fornecem informações importantes que nos ajudam a melhorar os tipos de produtos e serviços que oferecemos e como os fornecemos para você. Suas informações pessoais e suas respostas permanecerão estritamente confidenciais, mesmo que a pesquisa seja conduzida por terceiros. A participação em nossas pesquisas é voluntária.\r\n\r\nPodemos tomar as informações que recebemos dos indivíduos que respondem aos nossos inquéritos aos clientes e combiná-las com as respostas de outros clientes que possamos ter para criar respostas genéricas mais amplas às questões da pesquisa (como gênero, idade, residência, passatempos, educação, emprego, setor industrial ou outra informação demográfica). Então usamos a informação agregada para melhorar a qualidade de nossos serviços e desenvolver novos serviços e produtos. Esta informação agregada que não é pessoalmente identificável pode ser compartilhada com terceiros.\r\n\r\n<strong>Casos especiais:</strong>\r\n\r\nÉ política de nossa empresa não usar ou compartilhar informações pessoais sobre os Visitantes e Membros de maneiras não relacionadas às descritas acima, sem também lhe dar a oportunidade de optar por excluir ou proibir outros usos não relacionados.\r\n\r\nNo entanto, podemos divulgar informações pessoais sobre Visitantes ou Membros ou informações sobre o uso dos Serviços ou sites acessíveis através de nossos Serviços, por qualquer motivo se, a nosso exclusivo critério, acreditamos que seja razoável fazê-lo, incluindo: Agências; Agências de cobrança; Agências de banco de dados comerciais; Conformidade com a lei, ou para cumprir as leis, como a Lei de Privacidade de Comunicações Eletrônicas, a Lei de Privacidade de Crianças na Internet, os regulamentos ou os pedidos governamentais ou legais para tal informação; Divulgar informações que sejam necessárias para identificar, entrar em contato ou iniciar ações legais contra alguém que esteja violando nossa Política de Uso Aceitável ou Termos de Serviço ou outras políticas de usuários; Para operar os Serviços corretamente; Ou para proteger nossa empresa e nossos membros.\r\n\r\n<strong>\"Cookies\" e como nossa empresa os usa:</strong>\r\n\r\nUm \"cookie\" é um pequeno arquivo de dados que pode ser colocado em seu disco rígido quando você visita certas páginas da Web. Nossa empresa pode usar cookies para coletar, armazenar e, às vezes, rastrear informações com fins estatísticos para melhorar os produtos e serviços que oferecemos e gerenciar nossas redes de telecomunicações.\r\n\r\nSe você é Visitante ou Membro, podemos usar um cookie para salvar sua configuração e fornecer serviços personalizáveis e customizáveis. Esses cookies não permitem que terceiros acessem as informações do seu cliente. Além disso, tenha em mente que, se você visitar outros sites onde você é solicitado a fazer login ou que eles são personalizáveis, talvez seja necessário aceitar cookies.\r\n\r\nAnunciantes e parceiros também podem usar seus próprios cookies. Não controlamos o uso desses cookies e renunciamos expressamente à responsabilidade pelas informações coletadas através deles.\r\n\r\n<strong>Compromisso de nossa empresa com a privacidade de crianças:</strong>\r\n\r\nProteger a privacidade das crianças é especialmente importante para nós. É nossa política cumprir com a Lei de Proteção de Privacidade Online Infantil de 1998 e todas as demais leis aplicáveis. Portanto, restringimos nosso site para pessoas com idade superior a dezoito anos.\r\n\r\n<strong>As compras online:</strong>\r\n\r\nEm alguns sites, você pode comprar produtos e serviços ou se registrar para receber materiais, como uma newsletter, um catálogo ou um novo produto e atualizações de serviços. Em muitos casos, você pode ser solicitado a fornecer informações de contato, como seu nome, endereço, endereço de e-mail, número de telefone e informações de cartão de crédito / débito.\r\n\r\nSe você completar um pedido para outra pessoa, como um pedido de presente online enviado diretamente a um destinatário, você pode ser solicitado a fornecer informações sobre o destinatário, como o nome, o endereço e o número de telefone do destinatário. Nossa empresa não tem controle sobre o uso de terceiros para qualquer informação pessoal que você fornece ao fazer tal pedido. Tenha cuidado quando você faz isso.\r\n\r\nSe você solicitar serviços ou produtos diretamente de nossa empresa, usaremos as informações pessoais que você fornecerá apenas para processar esse pedido. Não compartilhamos essas informações com terceiros, exceto na medida necessária para concluir esse pedido.\r\n\r\nVocê deve ter dezoito (18) anos de idade ou mais para acessar este site. SE VOCÊ TEM MENOS DE DEZOITO ANOS DE IDADE, NÃO ESTÁ PERMITIDO A ACESSAR ESTE SITE DA WEB POR QUALQUER RAZÃO. DEVIDO ÀS RESTRIÇÕES DE IDADE PARA O USO DESTE SITE, NENHUMA INFORMAÇÃO OBTIDA POR ESTE SÍTIO DA WEB SE ENQUADRA NA LEI DE PRIVACIDADE ONLINE DE CRIANÇAS (COPA) E NÃO TEMOS CONTROLE SE O FAZEM.\r\n\r\n<strong>Fóruns públicos:</strong>\r\n\r\nLembre-se de que qualquer informação que você venha a divulgar em qualquer Diretório de Membros ou outras áreas públicas de nossos sites da Web ou Internet se tornam informações públicas. Você deve ter cuidado ao decidir revelar informações pessoais nessas áreas públicas.\r\n\r\n<strong>Compromisso da nossa empresa com a segurança dos dados:</strong>\r\n\r\nOs serviços e sites que patrocinamos têm medidas de segurança para proteger a perda, uso indevido e alteração das informações sob nosso controle. Embora façamos o nosso melhor para garantir a integridade e a segurança da nossa rede e sistemas, não podemos garantir que nossas medidas de segurança impeçam \"hackers\" de obter ilegalmente essa informação.\r\n\r\n<strong>Onde direcionar perguntas sobre nossa política de privacidade:</strong>\r\n\r\nSe você tiver alguma dúvida sobre esta Política de Privacidade ou as práticas descritas neste documento, você pode contatar-nos através das informações de contato fornecidas neste site.\r\n\r\n<strong>Revisões desta Política:</strong>\r\n\r\nNossa empresa se reserva o direito de revisar, alterar ou modificar esta política, nossos termos de serviço e nossas outras políticas e acordos a qualquer momento e de qualquer forma, atualizando esta publicação.","Política de Privacidade","","inherit","closed","closed","","51-revision-v1","","","2018-07-11 03:17:19","2018-07-11 06:17:19","","51","http://localhost/cbdmed/?p=52","0","revision","","0");
INSERT INTO wp_posts VALUES("53","1","2018-07-11 03:18:09","2018-07-11 06:18:09","<span class=\"zn-fontweight\"><strong>Para <span class=\"il\">devolução</span> de qualquer produto por qualquer motivo, o mesmo precisa estar com o lacre de segurança intacto e respeitar as seguintes condições:</strong></span>\r\n<ol>\r\n 	<li><span class=\"zn-fontweight\">Devoluções são aceitas dentro do prazo de 20 dias a partir da data de recebimento.</span></li>\r\n 	<li><span class=\"zn-fontweight\">Os produtos a serem devolvidos não podem ter sido abertos.</span></li>\r\n 	<li><span class=\"zn-fontweight\">Custos de frete não serão devolvidos.</span></li>\r\n 	<li><span class=\"zn-fontweight\">O cliente é responsável pelos custos de envio da devolução.</span></li>\r\n 	<li><span class=\"zn-fontweight\">O reembolso será processado assim que o retorno dos produtos for confirmado.</span></li>\r\n 	<li><span class=\"zn-fontweight\">É necessário uma Autorização de Devolução de Mercadoria para qualquer reembolso (entre em contato conosco).</span></li>\r\n</ol>\r\n<span class=\"zn-fontweight\"><strong>\r\nCondições de venda - Política de Reembolso</strong></span>\r\n\r\n<span class=\"zn-fontweight\">Durante o processo de pagamento você receberá todos os termos relacionados a sua compra. A aceitação destes termos comprova que você está ciente de que estes produtos contêm CBD (canabidiol) de óleo de cânhamo. Estes produtos não foram avaliados pelo FDA ou ANVISA. Estamos empenhados em cumprir com os regulamentos do FDA e, uma vez que esses produtos não foram avaliados pela agência reguladora, não fazemos qualquer reivindicação sobre benefícios adicionais de produtos que contenham CBD (canabidiol). Ao decidir comprar nossos produtos você assume a responsabilidade por suas próprias opiniões quanto aos benefícios ou uso dos mesmos.</span>\r\n\r\n<span class=\"zn-fontweight\">Devido à natureza perecível do Real Scientific Hemp Oil™ não podemos fornecer um reembolso para um produto aberto. Se você tiver quaisquer dúvidas, entre em contato com nossa equipe de vendas antes de comprar o produto. Telefones: RJ (21) 4042-2095 ou SP (11) 4200-0618 – de segunda à sexta das 11:00 às 23:00h.\r\n</span>\r\n\r\n<span class=\"zn-fontweight\"><strong>Política de envios</strong></span>\r\n\r\n<span class=\"zn-fontweight\">A HempMeds® Brasil envia através da UPS dos Estados Unidos. Os pedidos internacionais podem incluir taxas adicionais e devem cumprir com os regulamentos de venda destes produtos no país. Lembramos que após enviado de San Diego, não podemos cancelar um pedido, pois o serviço de frete é terceirizado.</span>\r\n\r\n<span class=\"zn-fontweight\">Política de cancelamento</span>\r\n\r\n<span class=\"zn-fontweight\">Aceitamos o cancelamento de pedidos somente quando os mesmos ainda não foram despachados. Portanto, caso o produto já tenha saído de nossa empresa, não poderemos cancelar o pedido, uma vez que não conseguimos interromper o envio de uma carga já em rota.</span>\r\n\r\n<span class=\"zn-fontweight\"><strong>Em quanto tempo vou receber minha encomenda?</strong></span>\r\n\r\n<span class=\"zn-fontweight\">Os clientes nos Estados Unidos têm recebido seus pedidos entre 7 e 10 dias úteis. As encomendas internacionais (como as daqui de San Diego para o Brasil) estão com um prazo de entrega estimado em 15 dias, dependendo do destino final. Pedidos recebidos depois das 14:00h (horário do Pacífico) são enviados no dia útil seguinte.</span>\r\n\r\n<span class=\"zn-fontweight\">ATENÇÃO! Os clientes são responsáveis por verificar se houve qualquer dano à remessa recebida no momento da entrega. As reclamações associadas a produtos danificados durante o transporte devem ser protocoladas no prazo de 72 horas do recebimento.</span>\r\n\r\n<span class=\"zn-fontweight\"><strong>Danos durante o envio</strong></span>\r\n\r\n<span class=\"zn-fontweight\">A satisfação de nossos clientes é de suma importância para nós. Todos os nossos produtos passam por um rígido controle de qualidade e todas as remessas são cuidadosamente inspecionadas antes de deixar a nossa distribuidora.</span>\r\n\r\n<span class=\"zn-fontweight\">Por favor, verifique a sua encomenda cuidadosamente na chegada para garantir que ela não foi danificada durante o transporte. Todas as reclamações relacionadas a produtos danificados devem ser feitas dentro de 72 horas do recebimento. Entre em contato conosco para esclarecer suas dúvidas.</span>","Política de Devolução","","publish","closed","closed","","politica-de-devolucao","","","2018-07-11 03:18:09","2018-07-11 06:18:09","","0","http://localhost/cbdmed/?page_id=53","0","page","","0");
INSERT INTO wp_posts VALUES("54","1","2018-07-11 03:18:09","2018-07-11 06:18:09","<span class=\"zn-fontweight\"><strong>Para <span class=\"il\">devolução</span> de qualquer produto por qualquer motivo, o mesmo precisa estar com o lacre de segurança intacto e respeitar as seguintes condições:</strong></span>\r\n<ol>\r\n 	<li><span class=\"zn-fontweight\">Devoluções são aceitas dentro do prazo de 20 dias a partir da data de recebimento.</span></li>\r\n 	<li><span class=\"zn-fontweight\">Os produtos a serem devolvidos não podem ter sido abertos.</span></li>\r\n 	<li><span class=\"zn-fontweight\">Custos de frete não serão devolvidos.</span></li>\r\n 	<li><span class=\"zn-fontweight\">O cliente é responsável pelos custos de envio da devolução.</span></li>\r\n 	<li><span class=\"zn-fontweight\">O reembolso será processado assim que o retorno dos produtos for confirmado.</span></li>\r\n 	<li><span class=\"zn-fontweight\">É necessário uma Autorização de Devolução de Mercadoria para qualquer reembolso (entre em contato conosco).</span></li>\r\n</ol>\r\n<span class=\"zn-fontweight\"><strong>\r\nCondições de venda - Política de Reembolso</strong></span>\r\n\r\n<span class=\"zn-fontweight\">Durante o processo de pagamento você receberá todos os termos relacionados a sua compra. A aceitação destes termos comprova que você está ciente de que estes produtos contêm CBD (canabidiol) de óleo de cânhamo. Estes produtos não foram avaliados pelo FDA ou ANVISA. Estamos empenhados em cumprir com os regulamentos do FDA e, uma vez que esses produtos não foram avaliados pela agência reguladora, não fazemos qualquer reivindicação sobre benefícios adicionais de produtos que contenham CBD (canabidiol). Ao decidir comprar nossos produtos você assume a responsabilidade por suas próprias opiniões quanto aos benefícios ou uso dos mesmos.</span>\r\n\r\n<span class=\"zn-fontweight\">Devido à natureza perecível do Real Scientific Hemp Oil™ não podemos fornecer um reembolso para um produto aberto. Se você tiver quaisquer dúvidas, entre em contato com nossa equipe de vendas antes de comprar o produto. Telefones: RJ (21) 4042-2095 ou SP (11) 4200-0618 – de segunda à sexta das 11:00 às 23:00h.\r\n</span>\r\n\r\n<span class=\"zn-fontweight\"><strong>Política de envios</strong></span>\r\n\r\n<span class=\"zn-fontweight\">A HempMeds® Brasil envia através da UPS dos Estados Unidos. Os pedidos internacionais podem incluir taxas adicionais e devem cumprir com os regulamentos de venda destes produtos no país. Lembramos que após enviado de San Diego, não podemos cancelar um pedido, pois o serviço de frete é terceirizado.</span>\r\n\r\n<span class=\"zn-fontweight\">Política de cancelamento</span>\r\n\r\n<span class=\"zn-fontweight\">Aceitamos o cancelamento de pedidos somente quando os mesmos ainda não foram despachados. Portanto, caso o produto já tenha saído de nossa empresa, não poderemos cancelar o pedido, uma vez que não conseguimos interromper o envio de uma carga já em rota.</span>\r\n\r\n<span class=\"zn-fontweight\"><strong>Em quanto tempo vou receber minha encomenda?</strong></span>\r\n\r\n<span class=\"zn-fontweight\">Os clientes nos Estados Unidos têm recebido seus pedidos entre 7 e 10 dias úteis. As encomendas internacionais (como as daqui de San Diego para o Brasil) estão com um prazo de entrega estimado em 15 dias, dependendo do destino final. Pedidos recebidos depois das 14:00h (horário do Pacífico) são enviados no dia útil seguinte.</span>\r\n\r\n<span class=\"zn-fontweight\">ATENÇÃO! Os clientes são responsáveis por verificar se houve qualquer dano à remessa recebida no momento da entrega. As reclamações associadas a produtos danificados durante o transporte devem ser protocoladas no prazo de 72 horas do recebimento.</span>\r\n\r\n<span class=\"zn-fontweight\"><strong>Danos durante o envio</strong></span>\r\n\r\n<span class=\"zn-fontweight\">A satisfação de nossos clientes é de suma importância para nós. Todos os nossos produtos passam por um rígido controle de qualidade e todas as remessas são cuidadosamente inspecionadas antes de deixar a nossa distribuidora.</span>\r\n\r\n<span class=\"zn-fontweight\">Por favor, verifique a sua encomenda cuidadosamente na chegada para garantir que ela não foi danificada durante o transporte. Todas as reclamações relacionadas a produtos danificados devem ser feitas dentro de 72 horas do recebimento. Entre em contato conosco para esclarecer suas dúvidas.</span>","Política de Devolução","","inherit","closed","closed","","53-revision-v1","","","2018-07-11 03:18:09","2018-07-11 06:18:09","","53","http://localhost/cbdmed/?p=54","0","revision","","0");



CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_term_relationships VALUES("20","16","0");
INSERT INTO wp_term_relationships VALUES("21","16","0");
INSERT INTO wp_term_relationships VALUES("22","16","0");
INSERT INTO wp_term_relationships VALUES("30","16","0");
INSERT INTO wp_term_relationships VALUES("33","16","0");
INSERT INTO wp_term_relationships VALUES("36","16","0");
INSERT INTO wp_term_relationships VALUES("39","16","0");
INSERT INTO wp_term_relationships VALUES("42","16","0");
INSERT INTO wp_term_relationships VALUES("43","1","0");
INSERT INTO wp_term_relationships VALUES("46","1","0");



CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_term_taxonomy VALUES("1","1","category","","0","2");
INSERT INTO wp_term_taxonomy VALUES("2","2","product_type","","0","0");
INSERT INTO wp_term_taxonomy VALUES("3","3","product_type","","0","0");
INSERT INTO wp_term_taxonomy VALUES("4","4","product_type","","0","0");
INSERT INTO wp_term_taxonomy VALUES("5","5","product_type","","0","0");
INSERT INTO wp_term_taxonomy VALUES("6","6","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("7","7","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("8","8","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("9","9","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("10","10","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("11","11","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("12","12","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("13","13","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("14","14","product_visibility","","0","0");
INSERT INTO wp_term_taxonomy VALUES("15","15","product_cat","","0","0");
INSERT INTO wp_term_taxonomy VALUES("16","16","nav_menu","","0","8");



CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_terms VALUES("1","Sem categoria","sem-categoria","0");
INSERT INTO wp_terms VALUES("2","simple","simple","0");
INSERT INTO wp_terms VALUES("3","grouped","grouped","0");
INSERT INTO wp_terms VALUES("4","variable","variable","0");
INSERT INTO wp_terms VALUES("5","external","external","0");
INSERT INTO wp_terms VALUES("6","exclude-from-search","exclude-from-search","0");
INSERT INTO wp_terms VALUES("7","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO wp_terms VALUES("8","featured","featured","0");
INSERT INTO wp_terms VALUES("9","outofstock","outofstock","0");
INSERT INTO wp_terms VALUES("10","rated-1","rated-1","0");
INSERT INTO wp_terms VALUES("11","rated-2","rated-2","0");
INSERT INTO wp_terms VALUES("12","rated-3","rated-3","0");
INSERT INTO wp_terms VALUES("13","rated-4","rated-4","0");
INSERT INTO wp_terms VALUES("14","rated-5","rated-5","0");
INSERT INTO wp_terms VALUES("15","Uncategorized","uncategorized","0");
INSERT INTO wp_terms VALUES("16","Menu Principal","menu-principal","0");



CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_usermeta VALUES("1","1","nickname","admin");
INSERT INTO wp_usermeta VALUES("2","1","first_name","");
INSERT INTO wp_usermeta VALUES("3","1","last_name","");
INSERT INTO wp_usermeta VALUES("4","1","description","");
INSERT INTO wp_usermeta VALUES("5","1","rich_editing","true");
INSERT INTO wp_usermeta VALUES("6","1","syntax_highlighting","true");
INSERT INTO wp_usermeta VALUES("7","1","comment_shortcuts","false");
INSERT INTO wp_usermeta VALUES("8","1","admin_color","fresh");
INSERT INTO wp_usermeta VALUES("9","1","use_ssl","0");
INSERT INTO wp_usermeta VALUES("10","1","show_admin_bar_front","true");
INSERT INTO wp_usermeta VALUES("11","1","locale","");
INSERT INTO wp_usermeta VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO wp_usermeta VALUES("13","1","wp_user_level","10");
INSERT INTO wp_usermeta VALUES("14","1","dismissed_wp_pointers","wp496_privacy");
INSERT INTO wp_usermeta VALUES("15","1","show_welcome_panel","1");
INSERT INTO wp_usermeta VALUES("16","1","session_tokens","a:1:{s:64:\"a99a8ce7acdbb08ac7f585f778a85f9bfc61ed2714bb8e378e33d4d82964c9ef\";a:4:{s:10:\"expiration\";i:1532142635;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36\";s:5:\"login\";i:1530933035;}}");
INSERT INTO wp_usermeta VALUES("17","1","wp_dashboard_quick_press_last_post_id","4");
INSERT INTO wp_usermeta VALUES("18","1","_woocommerce_persistent_cart_1","a:1:{s:4:\"cart\";a:0:{}}");
INSERT INTO wp_usermeta VALUES("19","1","dismissed_no_secure_connection_notice","1");
INSERT INTO wp_usermeta VALUES("20","1","wc_last_active","1531267200");
INSERT INTO wp_usermeta VALUES("21","1","wp_user-settings","libraryContent=browse&editor_expand=off&hidetb=1&editor=tinymce");
INSERT INTO wp_usermeta VALUES("22","1","wp_user-settings-time","1531289584");
INSERT INTO wp_usermeta VALUES("23","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO wp_usermeta VALUES("24","1","metaboxhidden_nav-menus","a:4:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-product_cat\";i:3;s:15:\"add-product_tag\";}");
INSERT INTO wp_usermeta VALUES("25","1","nav_menu_recently_edited","16");
INSERT INTO wp_usermeta VALUES("26","1","closedpostboxes_post","a:0:{}");
INSERT INTO wp_usermeta VALUES("27","1","metaboxhidden_post","a:9:{i:0;s:11:\"categorydiv\";i:1;s:16:\"tagsdiv-post_tag\";i:2;s:11:\"postexcerpt\";i:3;s:13:\"trackbacksdiv\";i:4;s:10:\"postcustom\";i:5;s:16:\"commentstatusdiv\";i:6;s:11:\"commentsdiv\";i:7;s:7:\"slugdiv\";i:8;s:9:\"authordiv\";}");



CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_users VALUES("1","admin","$P$BfoJEsbGNdLB64cwgr7KuR8E/7DSG//","admin","hello@bulkdesign.com.br","","2018-07-03 02:44:35","","0","admin");



CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`),
  CONSTRAINT `fk_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_key`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wp_woocommerce_sessions VALUES("4","1","a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:715:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"PR\";s:7:\"country\";s:2:\"BR\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"PR\";s:16:\"shipping_country\";s:2:\"BR\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:23:\"hello@bulkdesign.com.br\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}","1531437695");



CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


